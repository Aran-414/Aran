
// CHECK-LABEL: func.func @addf_vector
//     CHECK-2:   vector.to_elements

//       CHECK:   arith.bitcast
//       CHECK:   arith.extui
//       CHECK:   arith.bitcast
//       CHECK:   arith.extui
//       CHECK:   call
//       CHECK:   arith.trunci

//       CHECK:   arith.bitcast
//       CHECK:   arith.extui
//       CHECK:   arith.bitcast
//       CHECK:   arith.extui
//       CHECK:   call
//       CHECK:   arith.trunci

//       CHECK:   arith.bitcast
//       CHECK:   arith.extui
//       CHECK:   arith.bitcast
//       CHECK:   arith.extui
//       CHECK:   call
//       CHECK:   arith.trunci

//       CHECK:   arith.bitcast
//       CHECK:   arith.extui
//       CHECK:   arith.bitcast
//       CHECK:   arith.extui
//       CHECK:   call
//       CHECK:   arith.trunci

//       CHECK:   vector.from_elements
func.func @addf_vector(%arg0: vector<4xf4E2M1FN>, %arg1: vector<4xf4E2M1FN>) {
  %0 = arith.addf %arg0, %arg1 : vector<4xf4E2M1FN>
  return
}
