
// CHECK: func.func private @_mlir_apfloat_compare(i32, i64, i64) -> i8
// CHECK: %[[sem:.*]] = arith.constant 18 : i32
// CHECK: %[[cmp:.*]] = call @_mlir_apfloat_compare(%[[sem]], %{{.*}}, %{{.*}}) : (i32, i64, i64) -> i8
// CHECK: %[[c3:.*]] = arith.constant 3 : i8
// CHECK: %[[is_unordered:.*]] = arith.cmpi eq, %[[cmp]], %[[c3]] : i8
// CHECK: %[[c0:.*]] = arith.constant 0 : i8
// CHECK: %[[is_lt:.*]] = arith.cmpi eq, %[[cmp]], %[[c0]] : i8
// CHECK: arith.ori %[[is_unordered]], %[[is_lt]] : i1
func.func @cmpf(%arg0: f4E2M1FN, %arg1: f4E2M1FN) {
  %0 = arith.cmpf "ult", %arg0, %arg1 : f4E2M1FN
  return
}

