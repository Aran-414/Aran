
// CHECK: func.func private @_mlir_apfloat_minnum(i32, i64, i64) -> i64
// CHECK: %[[sem:.*]] = arith.constant 2 : i32
// CHECK: %[[res:.*]] = call @_mlir_apfloat_minnum(%[[sem]], %{{.*}}, %{{.*}}) : (i32, i64, i64) -> i64
func.func @minnumf(%arg0: f32, %arg1: f32) {
  %0 = arith.minnumf %arg0, %arg1 : f32
  return
}

