
// Test decl collision (different type)
// expected-error@+1{{matched function '_mlir_apfloat_add' but with different type: '(i32, i32, f32) -> index' (expected '(i32, i64, i64) -> i64')}}
func.func private @_mlir_apfloat_add(i32, i32, f32) -> index
func.func @addf(%arg0: f4E2M1FN, %arg1: f4E2M1FN) {
  %0 = arith.addf %arg0, %arg1 : f4E2M1FN
  return
}

