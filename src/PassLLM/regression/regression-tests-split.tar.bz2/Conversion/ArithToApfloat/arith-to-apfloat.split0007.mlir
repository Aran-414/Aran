
// CHECK: func.func private @_mlir_apfloat_convert(i32, i32, i64) -> i64
// CHECK: %[[sem_in:.*]] = arith.constant 18 : i32
// CHECK: %[[sem_out:.*]] = arith.constant 2 : i32
// CHECK: call @_mlir_apfloat_convert(%[[sem_in]], %[[sem_out]], %{{.*}}) : (i32, i32, i64) -> i64
func.func @extf(%arg0: f4E2M1FN) {
  %0 = arith.extf %arg0 : f4E2M1FN to f32
  return
}

