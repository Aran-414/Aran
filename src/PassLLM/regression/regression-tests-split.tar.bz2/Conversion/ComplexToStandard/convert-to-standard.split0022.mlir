
// CHECK-LABEL: func.func @complex_pow_with_fmf
// CHECK-SAME: %[[LHS:.*]]: complex<f32>, %[[RHS:.*]]: complex<f32>
func.func @complex_pow_with_fmf(%lhs: complex<f32>,
                                %rhs: complex<f32>) -> complex<f32> {
  %pow = complex.pow %lhs, %rhs fastmath<nnan,contract> : complex<f32>
  return %pow : complex<f32>
}

// CHECK: %[[A:.*]] = complex.re %[[LHS]]
// CHECK: %[[B:.*]] = complex.im %[[LHS]]
// CHECK: math.atan2 %[[B]], %[[A]] fastmath<nnan,contract> : f32

