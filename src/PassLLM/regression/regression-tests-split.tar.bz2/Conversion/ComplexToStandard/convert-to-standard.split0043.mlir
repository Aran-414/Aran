
// CHECK-LABEL: func @complex_tanh_nnan_ninf
// CHECK-SAME: %[[ARG:.*]]: complex<f32>
func.func @complex_tanh_nnan_ninf(%arg: complex<f32>) -> complex<f32> {
  %tanh = complex.tanh %arg fastmath<nnan,ninf> : complex<f32>
  return %tanh : complex<f32>
}

// CHECK-COUNT-1: arith.select
// CHECK-NOT: arith.select

