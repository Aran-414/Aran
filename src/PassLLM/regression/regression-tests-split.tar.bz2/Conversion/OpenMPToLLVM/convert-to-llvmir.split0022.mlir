
// CHECK-LABEL: llvm.func @omp_distribute(
// CHECK-SAME:  %[[ARG0:.*]]: i64)
func.func @omp_distribute(%arg0 : index) -> () {
  // CHECK: omp.distribute dist_schedule_static dist_schedule_chunk_size(%[[ARG0]] : i64) {
  omp.distribute dist_schedule_static dist_schedule_chunk_size(%arg0 : index) {
    omp.loop_nest (%iv) : index = (%arg0) to (%arg0) step (%arg0) {
      omp.yield
    }
  }
  return
}

