
// CHECK-LABEL: llvm.func @omp_cancel_cancellation_point()
func.func @omp_cancel_cancellation_point() -> () {
  omp.parallel {
    // CHECK: omp.cancel cancellation_construct_type(parallel)
    omp.cancel cancellation_construct_type(parallel)
    // CHECK: omp.cancellation_point cancellation_construct_type(parallel)
    omp.cancellation_point cancellation_construct_type(parallel)
    omp.terminator
  }
  return
}

