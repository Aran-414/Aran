
// CHECK: omp.private {type = firstprivate} @y.privatizer : i64 copy {
omp.private {type = firstprivate} @y.privatizer : index copy {
// CHECK: ^bb0(%arg0: !llvm.ptr, %arg1: !llvm.ptr):
^bb0(%arg0: !llvm.ptr, %arg1: !llvm.ptr):
  // CHECK: omp.yield(%arg0 : !llvm.ptr)
  omp.yield(%arg0 : !llvm.ptr)
}

