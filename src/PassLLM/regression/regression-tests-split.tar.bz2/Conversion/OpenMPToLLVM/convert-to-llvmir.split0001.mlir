
// CHECK: omp.critical.declare @[[MUTEX:.*]] hint(contended, speculative)
omp.critical.declare @mutex hint(contended, speculative)

// CHECK: llvm.func @critical_declare
func.func @critical_declare() {
  // CHECK: omp.critical(@[[MUTEX]])
  omp.critical(@mutex) {
    omp.terminator
  }
  return
}

