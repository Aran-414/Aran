
// CHECK-LABEL: @threadprivate
// CHECK: (%[[ARG0:.*]]: !llvm.ptr)
// CHECK: %[[VAL0:.*]] = omp.threadprivate %[[ARG0]] : !llvm.ptr -> !llvm.ptr
func.func @threadprivate(%a: !llvm.ptr) -> () {
  %1 = omp.threadprivate %a : !llvm.ptr -> !llvm.ptr
  return
}

