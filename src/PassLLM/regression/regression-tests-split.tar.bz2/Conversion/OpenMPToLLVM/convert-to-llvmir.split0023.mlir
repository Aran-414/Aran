
// CHECK-LABEL: llvm.func @omp_teams(
// CHECK-SAME:  %[[ARG0:.*]]: !llvm.ptr, %[[ARG1:.*]]: !llvm.ptr, %[[ARG2:.*]]: i64)
func.func @omp_teams(%arg0 : memref<i32>) -> () {
  // CHECK: omp.teams allocate(%{{.*}} : !llvm.struct<(ptr, ptr, i64)> -> %{{.*}} : !llvm.struct<(ptr, ptr, i64)>)
  omp.teams allocate(%arg0 : memref<i32> -> %arg0 : memref<i32>) {
    omp.terminator
  }
  return
}

