
// CHECK-LABEL: omp.declare_mapper @my_mapper : !llvm.struct<"_QFdeclare_mapperTmy_type", (i32)> {
omp.declare_mapper @my_mapper : !llvm.struct<"_QFdeclare_mapperTmy_type", (i32)> {
^bb0(%arg0: !llvm.ptr):
  %0 = llvm.mlir.constant(0 : i32) : i32
  %1 = llvm.getelementptr %arg0[0, 0] : (!llvm.ptr) -> !llvm.ptr, !llvm.struct<"_QFdeclare_mapperTmy_type", (i32)>
  %2 = omp.map.info var_ptr(%1 : !llvm.ptr, i32) map_clauses(tofrom) capture(ByRef) -> !llvm.ptr {name = "var%data"}
  %3 = omp.map.info var_ptr(%arg0 : !llvm.ptr, !llvm.struct<"_QFdeclare_mapperTmy_type", (i32)>) map_clauses(tofrom) capture(ByRef) members(%2 : [0] : !llvm.ptr) -> !llvm.ptr {name = "var", partial_map = true}
  // CHECK: omp.declare_mapper.info map_entries(%{{.*}}, %{{.*}} : !llvm.ptr, !llvm.ptr)
  omp.declare_mapper.info map_entries(%3, %2 : !llvm.ptr, !llvm.ptr)
}

// CHECK-LABEL: llvm.func @omp_dist_schedule(%arg0: i32) {
func.func @omp_dist_schedule(%arg0: i32) {
  %c1_i32 = arith.constant 1 : i32
  // CHECK: %1 = llvm.mlir.constant(1024 : i32) : i32
  %c1024_i32 = arith.constant 1024 : i32
  %c16_i32 = arith.constant 16 : i32
  %c8_i32 = arith.constant 8 : i32
  omp.teams num_teams( to %c8_i32 : i32) thread_limit(%c16_i32 : i32) {
    // CHECK: omp.distribute dist_schedule_static dist_schedule_chunk_size(%1 : i32) {
    omp.distribute dist_schedule_static dist_schedule_chunk_size(%c1024_i32 : i32) {
      omp.loop_nest (%arg1) : i32 = (%c1_i32) to (%arg0) inclusive step (%c1_i32) {
        omp.terminator
      }
    }
    omp.terminator
  }
  return
}
