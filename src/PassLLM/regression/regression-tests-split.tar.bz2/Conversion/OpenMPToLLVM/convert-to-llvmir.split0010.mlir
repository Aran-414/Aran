
// CHECK-LABEL: @task_depend
// CHECK:  (%[[ARG0:.*]]: !llvm.ptr) {
// CHECK:  omp.task depend(taskdependin -> %[[ARG0]] : !llvm.ptr) {
// CHECK:    omp.terminator
// CHECK:  }
// CHECK:   llvm.return
// CHECK: }

func.func @task_depend(%arg0: !llvm.ptr) {
  omp.task depend(taskdependin -> %arg0 : !llvm.ptr) {
    omp.terminator
  }
  return
}

