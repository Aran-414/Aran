
// CHECK-LABEL: llvm.func @omp_ordered(
// CHECK-SAME:  %[[ARG0:.*]]: i64)
func.func @omp_ordered(%arg0 : index) -> () {
  omp.wsloop ordered(1) {
    omp.loop_nest (%iv) : index = (%arg0) to (%arg0) step (%arg0) {
      // CHECK: omp.ordered depend_vec(%[[ARG0]] : i64) {doacross_num_loops = 1 : i64}
      omp.ordered depend_vec(%arg0 : index) {doacross_num_loops = 1 : i64}
      omp.yield
    }
  }
  return
}

