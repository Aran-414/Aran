
func.func @testupdateop(%a: memref<f32>, %ifCond: i1) -> () {
  %0 = acc.update_device varPtr(%a : memref<f32>) -> memref<f32>
  acc.update if(%ifCond) dataOperands(%0 : memref<f32>)
  return
}

// CHECK:      func @testupdateop(%{{.*}}: memref<f32>, [[IFCOND:%.*]]: i1)
// CHECK:        scf.if [[IFCOND]] {
// CHECK:          acc.update dataOperands(%{{.*}} : memref<f32>)
// CHECK-NEXT:   }

