
func.func @update_false(%arg0: memref<f32>) {
  %false = arith.constant false
  %0 = acc.update_device varPtr(%arg0 : memref<f32>) -> memref<f32>
  acc.update if(%false) dataOperands(%0 : memref<f32>)
  return
}

// CHECK-LABEL: func.func @update_false
// CHECK-NOT:     acc.update dataOperands

