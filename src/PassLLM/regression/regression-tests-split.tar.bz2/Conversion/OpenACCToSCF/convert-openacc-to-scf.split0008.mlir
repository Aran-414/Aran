
func.func @exit_data_false(%d1 : memref<f32>) {
  %false = arith.constant false
  %0 = acc.getdeviceptr varPtr(%d1 : memref<f32>) -> memref<f32>
  acc.exit_data async if(%false) dataOperands(%0 : memref<f32>)
  acc.delete accPtr(%0 : memref<f32>)
  return
}

// CHECK-LABEL: func.func @exit_data_false
// CHECK-NOT:acc.exit_data

