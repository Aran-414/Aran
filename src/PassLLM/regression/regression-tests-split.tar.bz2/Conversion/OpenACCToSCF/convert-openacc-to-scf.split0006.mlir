
func.func @enter_data_false(%d1 : memref<f32>) {
  %false = arith.constant false
  %0 = acc.create varPtr(%d1 : memref<f32>) -> memref<f32>
  acc.enter_data async if(%false) dataOperands(%0 : memref<f32>)
  return
}

// CHECK-LABEL: func.func @enter_data_false
// CHECK-NOT:     acc.enter_data

