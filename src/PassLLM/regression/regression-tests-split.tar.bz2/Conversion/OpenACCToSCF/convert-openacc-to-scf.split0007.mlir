
func.func @exit_data_true(%d1 : memref<f32>) {
  %true = arith.constant true
  %0 = acc.getdeviceptr varPtr(%d1 : memref<f32>) -> memref<f32>
  acc.exit_data async if(%true) dataOperands(%0 : memref<f32>)
  acc.delete accPtr(%0 : memref<f32>)
  return
}

// CHECK-LABEL: func.func @exit_data_true
// CHECK-NOT:if
// CHECK:acc.exit_data async dataOperands

