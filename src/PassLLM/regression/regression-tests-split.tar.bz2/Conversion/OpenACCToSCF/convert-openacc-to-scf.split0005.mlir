
func.func @enter_data_true(%d1 : memref<f32>) {
  %true = arith.constant true
  %0 = acc.create varPtr(%d1 : memref<f32>) -> memref<f32>
  acc.enter_data async if(%true) dataOperands(%0 : memref<f32>)
  return
}

// CHECK-LABEL: func.func @enter_data_true
// CHECK-NOT:     if
// CHECK:           acc.enter_data async dataOperands

