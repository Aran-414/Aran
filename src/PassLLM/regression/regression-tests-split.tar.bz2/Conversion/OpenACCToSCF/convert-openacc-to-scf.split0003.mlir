
func.func @update_true(%arg0: memref<f32>) {
  %true = arith.constant true
  %0 = acc.update_device varPtr(%arg0 : memref<f32>) -> memref<f32>
  acc.update if(%true) dataOperands(%0 : memref<f32>)
  return
}

// CHECK-LABEL: func.func @update_true
// CHECK-NOT:     if
// CHECK:         acc.update dataOperands

