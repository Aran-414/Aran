// CHECK-LABEL: llvm.func @llvm.load
llvm.func @llvm.load(%a: !llvm.ptr<1>) -> i32 {
  // CHECK: xevm.DecorationCacheControl =
  // CHECK-SAME: 6442 : i32, 0 : i32, 1 : i32, 0 : i32
  // CHECK-SAME: 6442 : i32, 1 : i32, 1 : i32, 0 : i32
  %val = llvm.load %a {cache_control=#xevm.load_cache_control<L1uc_L2uc_L3uc>} : !llvm.ptr<1> -> i32
  llvm.return %val : i32
}

