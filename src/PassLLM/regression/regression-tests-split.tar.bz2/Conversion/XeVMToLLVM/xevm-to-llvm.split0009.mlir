// CHECK-LABEL: llvm.func spir_funccc @_Z22atomic_work_item_fenceiii(i32, i32, i32) attributes {no_unwind}
llvm.func @memfence() {
  // CHECK: %[[VAR0:.*]] = llvm.mlir.constant(4 : i32) : i32
  // CHECK: %[[VAR1:.*]] = llvm.mlir.constant(1 : i32) : i32
  // CHECK: %[[VAR2:.*]] = llvm.mlir.constant(2 : i32) : i32
  // CHECK: llvm.call spir_funccc @_Z22atomic_work_item_fenceiii(%[[VAR2]], %[[VAR0]], %[[VAR1]])
  // CHECK-SAME: {function_type = !llvm.func<void (i32, i32, i32)>, linkage = #llvm.linkage<external>, no_unwind,
  // CHECK-SAME:   sym_name = "_Z22atomic_work_item_fenceiii", visibility_ = 0 : i64} : (i32, i32, i32) -> ()
  xevm.memfence <{addrspace=#xevm.addr_space<global>, scope=#xevm.mem_scope<workgroup>}>
  llvm.return
}

