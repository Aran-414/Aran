// CHECK-LABEL: llvm.func @llvm.store
llvm.func @llvm.store(%a: !llvm.ptr<1>, %val: i32) {
  // CHECK: xevm.DecorationCacheControl =
  // CHECK-SAME: 6443 : i32, 0 : i32, 2 : i32, 0 : i32
  // CHECK-SAME: 6443 : i32, 1 : i32, 2 : i32, 0 : i32
  llvm.store %val, %a {cache_control=#xevm.store_cache_control<L1wt_L2uc_L3wb>} : i32, !llvm.ptr<1>
  llvm.return
}

