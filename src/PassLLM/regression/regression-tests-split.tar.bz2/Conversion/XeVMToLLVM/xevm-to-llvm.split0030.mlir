// CHECK-LABEL: llvm.func @group_count.z() -> i32 {
llvm.func @group_count.z() -> i32 {
  // CHECK: %[[VAR0:.*]] = llvm.mlir.constant(2 : i32) : i32
  %1 = xevm.group_count.z : i32
  llvm.return %1 : i32
}

