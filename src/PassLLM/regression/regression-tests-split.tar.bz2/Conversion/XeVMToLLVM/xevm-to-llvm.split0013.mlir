// CHECK-LABEL: llvm.func spir_funccc @_Z30intel_sub_group_block_read_us8PU3AS1t
// CHECK: llvm.func @blockload_as1(%[[ARG0:.*]]: !llvm.ptr<1>)
llvm.func @blockload_as1(%ptr: !llvm.ptr<1>) -> vector<8xi16> {
  // CHECK: %[[VAR0:.*]] = llvm.call spir_funccc @_Z30intel_sub_group_block_read_us8PU3AS1t(%[[ARG0]])
  // CHECK-SAME: {function_type = !llvm.func<vector<8xi16> (ptr<1>)>, linkage = #llvm.linkage<external>,
  // CHECK-SAME:  no_unwind, sym_name = "_Z30intel_sub_group_block_read_us8PU3AS1t",
  // CHECK-SAME:  visibility_ = 0 : i64, will_return, xevm.DecorationCacheControl =
  // CHECK-SAME:    [6442 : i32, 0 : i32, 1 : i32, 0 : i32],
  // CHECK-SAME:    [6442 : i32, 1 : i32, 1 : i32, 0 : i32]
  %loaded_a = xevm.blockload %ptr <{cache_control=#xevm.load_cache_control<L1uc_L2uc_L3uc>}> : (!llvm.ptr<1>) -> vector<8xi16>
  llvm.return %loaded_a : vector<8xi16>
}

