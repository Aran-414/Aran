// CHECK-LABEL: llvm.func @group_count.y() -> i32 {
llvm.func @group_count.y() -> i32 {
  // CHECK: %[[VAR0:.*]] = llvm.mlir.constant(1 : i32) : i32
  %1 = xevm.group_count.y : i32
  llvm.return %1 : i32
}

