// CHECK-LABEL: llvm.func @group_count.x() -> i32 {
llvm.func @group_count.x() -> i32 {
  // CHECK: %[[VAR0:.*]] = llvm.mlir.constant(0 : i32) : i32
  // CHECK: %[[VAR1:.*]] = llvm.call spir_funccc @_Z14get_num_groupsj(%[[VAR0]])
  // CHECK-SAME: {function_type = !llvm.func<i32 (i32)>, linkage = #llvm.linkage<external>,
  // CHECK-SAME:  memory_effects = #llvm.memory_effects<other = none, argMem = none, inaccessibleMem = none, errnoMem = none, targetMem0 = none, targetMem1 = none>,
  // CHECK-SAME:  no_unwind, sym_name = "_Z14get_num_groupsj", visibility_ = 0 : i64, will_return} : (i32) -> i32
  %1 = xevm.group_count.x : i32
  llvm.return %1 : i32
}

