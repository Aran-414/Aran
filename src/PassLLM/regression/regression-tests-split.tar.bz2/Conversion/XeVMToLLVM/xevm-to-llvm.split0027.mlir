// CHECK-LABEL: llvm.func @group_id.z() -> i32 {
llvm.func @group_id.z() -> i32 {
  // CHECK: %[[VAR0:.*]] = llvm.mlir.constant(2 : i32) : i32
  %1 = xevm.group_id.z : i32
  llvm.return %1 : i32
}

