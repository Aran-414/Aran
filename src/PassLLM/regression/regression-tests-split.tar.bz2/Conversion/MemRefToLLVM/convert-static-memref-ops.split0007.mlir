
// CHECK-LABEL: func @zero_d_load
func.func @zero_d_load(%arg0: memref<f32>) -> f32 {
// CHECK: %[[ptr:.*]] = llvm.extractvalue %{{.*}}[1] : !llvm.struct<(ptr, ptr, i64)>
// CHECK: %{{.*}} = llvm.load %[[ptr]] : !llvm.ptr -> f32
  %0 = memref.load %arg0[] : memref<f32>
  return %0 : f32
}

