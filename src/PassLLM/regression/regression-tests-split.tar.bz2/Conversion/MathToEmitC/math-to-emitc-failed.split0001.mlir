
func.func @unsupported_f16_type(%arg0 : f16) -> f16 {
// expected-error @+1 {{failed to legalize operation 'math.absf' that was explicitly marked illegal}}
  %0 = math.absf %arg0 : f16
  return %0 : f16
}

