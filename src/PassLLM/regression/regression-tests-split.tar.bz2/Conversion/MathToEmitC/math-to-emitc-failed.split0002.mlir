
func.func @unsupported_f128_type(%arg0 : f128) -> f128 {
// expected-error @+1 {{failed to legalize operation 'math.absf' that was explicitly marked illegal}}
  %0 = math.absf %arg0 : f128
  return %0 : f128
}
