
// Cannot convert due to value type not being supported by the conversion

gpu.module @not_supported_lowering {
  llvm.func @gpu_shuffles(%val: f128, %id: i32) attributes {intel_reqd_sub_group_size = 32 : i32} {
    %width = arith.constant 32 : i32
    // expected-error@below {{failed to legalize operation 'gpu.shuffle' that was explicitly marked illegal}}
    %shuffleResult, %valid = gpu.shuffle xor %val, %id, %width : f128
    llvm.return
  }
}


