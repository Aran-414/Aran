
#map = affine_map<(m, n, k, vnni) -> (m, k, vnni)>
#map1 = affine_map<(m, n, k, vnni) -> (k, n, vnni)>
#map2 = affine_map<(m, n, k, vnni) -> (m, n)>
func.func @negative_non_identity_map(%C: memref<64x64xf32>,
    %vecA: vector<4x8x2xf16>, %vecB: vector<8x16x2xf16>,
    %vecC: vector<4x16xf32>, %idx: index) {
  %vecD = vector.contract
    {kind = #vector.kind<add>,
    indexing_maps = [#map, #map1, #map2],
    iterator_types = ["parallel", "parallel", "reduction", "reduction"]}
    %vecA, %vecB, %vecC : vector<4x8x2xf16>, vector<8x16x2xf16> into vector<4x16xf32>
  vector.transfer_write %vecD, %C[%idx, %idx]
    {permutation_map = affine_map<(d0, d1) -> (d1, d0)>,
    in_bounds = [true, true]} : vector<4x16xf32>, memref<64x64xf32>
  return
}

// CHECK-LABEL: @negative_non_identity_map(
// CHECK-SAME:    %[[C:.+]]: memref<64x64xf32>
// CHECK: vector.transfer_write{{.*}}%[[C]]

