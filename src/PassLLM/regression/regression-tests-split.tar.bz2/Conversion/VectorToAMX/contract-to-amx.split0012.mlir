
#map = affine_map<(m, n, k, vnni) -> (k, vnni, m)>
#map1 = affine_map<(m, n, k, vnni) -> (n, k, vnni)>
#map2 = affine_map<(m, n, k, vnni) -> (m, n)>
func.func @negative_input_dim_permutation(%A: vector<2x2x2xf16>,
    %B: vector<2x2x2xf16>, %C: vector<2x2xf32>) -> vector<2x2xf32> {
  %0 = vector.contract
    {kind = #vector.kind<add>,
    indexing_maps = [#map, #map1, #map2],
    iterator_types = ["parallel", "parallel", "reduction", "reduction"]}
    %A, %B, %C : vector<2x2x2xf16>, vector<2x2x2xf16> into vector<2x2xf32>
  return %0 : vector<2x2xf32>
}

// CHECK-LABEL: @negative_input_dim_permutation(
// CHECK-NOT: amx
// CHECK: vector.contract

