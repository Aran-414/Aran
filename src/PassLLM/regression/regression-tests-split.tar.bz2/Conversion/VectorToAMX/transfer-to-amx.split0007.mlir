
/// Buffer shape checks are conservative to avoid problems with deriving
/// stride for AMX tile rows.
/// When in doubt, vector operations are left to perform initial transfers.
/// Afterwards, data can be placed in a contiguous temporary buffer which
/// ensures correct layout for AMX transfers.

#map = affine_map<(m, n, k, vnni) -> (m, k, vnni)>
#map1 = affine_map<(m, n, k, vnni) -> (k, n, vnni)>
#map2 = affine_map<(m, n, k, vnni) -> (m, n)>
func.func @negative_1D_buffer(%C: memref<512xf32>,
    %vecA: vector<4x8x2xf16>, %vecB: vector<8x16x2xf16>,
    %idx: index) -> vector<4x16xf32> {
  %c0_f32 = arith.constant 0.0 : f32
  %vecC = vector.transfer_read %C[%idx], %c0_f32
    {permutation_map = affine_map<(d0) -> (0, d0)>,
    in_bounds = [true, true]} : memref<512xf32>, vector<4x16xf32>
  %vecD = vector.contract
    {kind = #vector.kind<add>,
    indexing_maps = [#map, #map1, #map2],
    iterator_types = ["parallel", "parallel", "reduction", "reduction"]}
    %vecA, %vecB, %vecC : vector<4x8x2xf16>, vector<8x16x2xf16> into vector<4x16xf32>
  return %vecD : vector<4x16xf32>
}

// CHECK-LABEL: @negative_1D_buffer(
// CHECK-SAME:    %[[C:.+]]: memref<512xf32>
// CHECK: vector.transfer_read %[[C]]

