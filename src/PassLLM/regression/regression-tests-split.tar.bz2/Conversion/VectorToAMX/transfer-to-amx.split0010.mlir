
#map = affine_map<(m, n, k, vnni) -> (m, k, vnni)>
#map1 = affine_map<(m, n, k, vnni) -> (k, n, vnni)>
#map2 = affine_map<(m, n, k, vnni) -> (m, n)>
func.func @negative_buffer_non_packed_source_shape(%A: memref<8x64x64xf16>,
    %vecB: vector<8x16x2xf16>, %vecC: vector<4x16xf32>,
    %idx: index) -> vector<4x16xf32> {
  %c0_f16 = arith.constant 0.0 : f16
  %vecA = vector.transfer_read %A[%idx, %idx, %idx], %c0_f16
    {in_bounds = [true, true, true]} : memref<8x64x64xf16>, vector<4x8x2xf16>
  %vecD = vector.contract
    {kind = #vector.kind<add>,
    indexing_maps = [#map, #map1, #map2],
    iterator_types = ["parallel", "parallel", "reduction", "reduction"]}
    %vecA, %vecB, %vecC : vector<4x8x2xf16>, vector<8x16x2xf16> into vector<4x16xf32>
  return %vecD : vector<4x16xf32>
}

// CHECK-LABEL: @negative_buffer_non_packed_source_shape(
// CHECK-SAME:    %[[A:.+]]: memref<8x64x64xf16>
// CHECK: vector.transfer_read %[[A]]
