
#map = affine_map<(m, k, vnni) -> (m, k, vnni)>
#map1 = affine_map<(m, k, vnni) -> (k, m, vnni)>
#map2 = affine_map<(m, k, vnni) -> ()>
func.func @negative_non_vector_acc(%A: vector<4x8x2xf16>, %B: vector<8x4x2xf16>,
    %C: f32) -> f32 {
  %0 = vector.contract
    {kind = #vector.kind<add>,
    indexing_maps = [#map, #map1, #map2],
    iterator_types = ["reduction", "reduction", "reduction"]}
    %A, %B, %C : vector<4x8x2xf16>, vector<8x4x2xf16> into f32
  return %0 : f32
}

// CHECK-LABEL: @negative_non_vector_acc(
// CHECK-NOT: amx
// CHECK: vector.contract

