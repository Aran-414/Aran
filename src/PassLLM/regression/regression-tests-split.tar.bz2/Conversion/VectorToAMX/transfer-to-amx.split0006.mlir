
/// AMX tile transfers require row elements to be contiguous

#map = affine_map<(m, n, k, vnni) -> (m, k, vnni)>
#map1 = affine_map<(m, n, k, vnni) -> (k, n, vnni)>
#map2 = affine_map<(m, n, k, vnni) -> (m, n)>
func.func @negative_non_contiguous_row(
    %A: memref<8x128x2xf16, strided<[256, 4, 1]>>,
    %vecB: vector<8x16x2xf16>, %vecC: vector<4x16xf32>,
    %idx: index) -> vector<4x16xf32> {
  %c0_f16 = arith.constant 0.0 : f16
  %vecA = vector.transfer_read %A[%idx, %idx, %idx], %c0_f16
    {in_bounds = [true, true, true]}
    : memref<8x128x2xf16, strided<[256, 4, 1]>>, vector<4x8x2xf16>
  %vecD = vector.contract
    {kind = #vector.kind<add>,
    indexing_maps = [#map, #map1, #map2],
    iterator_types = ["parallel", "parallel", "reduction", "reduction"]}
    %vecA, %vecB, %vecC : vector<4x8x2xf16>, vector<8x16x2xf16> into vector<4x16xf32>
  return %vecD : vector<4x16xf32>
}

// CHECK-LABEL: @negative_non_contiguous_row(
// CHECK-SAME:    %[[A:.+]]: memref<8x128x2xf16, strided<[256, 4, 1]>>
// CHECK: vector.transfer_read %[[A]]

