
#map = affine_map<(vnni, m, k, n) -> (m, k, vnni)>
#map1 = affine_map<(vnni, m, k, n) -> (k, n, vnni)>
#map2 = affine_map<(vnni, m, k, n) -> (m, n)>
func.func @contract_shuffled_iterators(%A: vector<4x16x4xi8>, %B: vector<16x8x4xi8>,
    %C: vector<4x8xi32>) -> vector<4x8xi32> {
  %0 = vector.contract
    {kind = #vector.kind<add>,
    indexing_maps = [#map, #map1, #map2],
    iterator_types = ["reduction", "parallel", "reduction", "parallel"]}
    %A, %B, %C : vector<4x16x4xi8>, vector<16x8x4xi8> into vector<4x8xi32>
  return %0 : vector<4x8xi32>
}

// CHECK-LABEL: @contract_shuffled_iterators(
// CHECK-COUNT-3: amx.tile_load
// CHECK: amx.tile_muli
// CHECK: amx.tile_store

