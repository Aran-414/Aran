// RUN: mlir-opt %s -convert-vector-to-amx -split-input-file | FileCheck %s

/// VNNI format is Intel's packed data layout.
/// For matrix multiplication, elements from the reduction dimension `k`
/// are packed into 32-bit tuples. Then the appropriate AMX operations can
/// perform tile multiplication directly on the packed data.
///
/// These packed elements are represented in the indexing maps by a separate
/// reduction dimension `vnni`.

#map = affine_map<(m, n, k, vnni) -> (m, k, vnni)>
#map1 = affine_map<(m, n, k, vnni) -> (k, n, vnni)>
#map2 = affine_map<(m, n, k, vnni) -> (m, n)>
func.func @contract_vnni_f16(%A: vector<4x8x2xf16>, %B: vector<8x16x2xf16>,
    %C: vector<4x16xf32>) -> vector<4x16xf32> {
  %0 = vector.contract
    {kind = #vector.kind<add>,
    indexing_maps = [#map, #map1, #map2],
    iterator_types = ["parallel", "parallel", "reduction", "reduction"]}
    %A, %B, %C : vector<4x8x2xf16>, vector<8x16x2xf16> into vector<4x16xf32>
  return %0 : vector<4x16xf32>
}

// CHECK-LABEL: @contract_vnni_f16(
// CHECK-SAME:    %[[A:.+]]: vector<4x8x2xf16>,
// CHECK-SAME:    %[[B:.+]]: vector<8x16x2xf16>,
// CHECK-SAME:    %[[C:.+]]: vector<4x16xf32>

/// AMX hardware has no direct access to the registers. Thus, data must
/// be transfered through intermediate buffers.
///
/// Load A vector into an AMX tile
// CHECK:       %[[A_BUF:.+]] = memref.alloca() : memref<4x8x2xf16>
// CHECK:       vector.transfer_write %[[A]], %[[A_BUF]]
// CHECK:       %[[A_BUF_2D:.+]] = memref.collapse_shape %[[A_BUF]]
// CHECK-SAME:    {{\[}}[0], [1, 2]] : memref<4x8x2xf16> into memref<4x16xf16>
// CHECK:       %[[A_TILE:.+]] = amx.tile_load %[[A_BUF_2D]]

/// Load B vector into an AMX tile
// CHECK:       %[[B_BUF:.+]] = memref.alloca() : memref<8x16x2xf16>
// CHECK:       vector.transfer_write %[[B]], %[[B_BUF]]
// CHECK:       %[[B_BUF_2D:.+]] = memref.collapse_shape %[[B_BUF]]
// CHECK-SAME:    {{\[}}[0], [1, 2]] : memref<8x16x2xf16> into memref<8x32xf16>
// CHECK:       %[[B_TILE:.+]] = amx.tile_load %[[B_BUF_2D]]

/// Load C vector into an AMX tile
// CHECK:       %[[C_BUF:.+]] = memref.alloca() : memref<4x16xf32>
// CHECK:       vector.transfer_write %[[C]], %[[C_BUF]]
// CHECK:       %[[C_TILE:.+]] = amx.tile_load %[[C_BUF]]

/// Perform tile multiplication
// CHECK:       %[[RES:.+]] = amx.tile_mulf
// CHECK-SAME:    %[[A_TILE]], %[[B_TILE]], %[[C_TILE]]

/// Load the result back into a vector
// CHECK:       %[[RES_BUF:.+]] = memref.alloca() : memref<4x16xf32>
// CHECK:       amx.tile_store %[[RES_BUF]]{{.*}}, %[[RES]]
// CHECK:       %[[RES_VEC:.+]] = vector.transfer_read %[[RES_BUF]]

// CHECK:       return %[[RES_VEC]]

