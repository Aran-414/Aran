
#map = affine_map<(m, n, k) -> (m, k)>
#map1 = affine_map<(m, n, k) -> (k, n)>
#map2 = affine_map<(m, n, k) -> (m, n)>
func.func @negative_non_packed_layout(%A: vector<4x16xf16>, %B: vector<16x16xf16>,
    %C: vector<4x16xf32>) -> vector<4x16xf32> {
  %0 = vector.contract
    {kind = #vector.kind<add>,
    indexing_maps = [#map, #map1, #map2],
    iterator_types = ["parallel", "parallel", "reduction"]}
    %A, %B, %C : vector<4x16xf16>, vector<16x16xf16> into vector<4x16xf32>
  return %0 : vector<4x16xf32>
}

// CHECK-LABEL: @negative_non_packed_layout(
// CHECK-NOT: amx
// CHECK: vector.contract

