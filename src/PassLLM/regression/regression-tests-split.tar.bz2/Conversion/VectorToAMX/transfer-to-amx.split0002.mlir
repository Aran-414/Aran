
/// AMX tile can be loaded directly from the buffer. However, vector transfer
/// has to remain due to other users that require data in registers.

#map = affine_map<(m, n, k, vnni) -> (m, k, vnni)>
#map1 = affine_map<(m, n, k, vnni) -> (k, n, vnni)>
#map2 = affine_map<(m, n, k, vnni) -> (m, n)>
func.func @transfer_read_multiple_users(%C: memref<64x64xf32>,
    %vecA: vector<4x8x2xf16>, %vecB: vector<8x16x2xf16>,
    %idx: index) -> vector<4x16xf32> {
  %c0_f32 = arith.constant 0.0 : f32
  %vecC = vector.transfer_read %C[%idx, %idx], %c0_f32
    {in_bounds = [true, true]} : memref<64x64xf32>, vector<4x16xf32>
  %vecD = vector.contract
    {kind = #vector.kind<add>,
    indexing_maps = [#map, #map1, #map2],
    iterator_types = ["parallel", "parallel", "reduction", "reduction"]}
    %vecA, %vecB, %vecC : vector<4x8x2xf16>, vector<8x16x2xf16> into vector<4x16xf32>
  %mul = arith.mulf %vecC, %vecD : vector<4x16xf32>
  return %mul : vector<4x16xf32>
}

// CHECK-LABEL: @transfer_read_multiple_users(
// CHECK-SAME:    %[[C:.+]]: memref<64x64xf32>,

/// Load to AMX tile directly from buffer.
// CHECK: %[[C_SUBVIEW:.+]] = memref.subview %[[C]]
// CHECK: %[[C_TILE:.+]] = amx.tile_load %[[C_SUBVIEW]]

/// Vector read remains to load data for the other non-AMX consumer.
// CHECK: %[[C_VEC:.+]] = vector.transfer_read %[[C]]

/// Contraction uses the directly loaded tile.
// CHECK: %[[TILE_MUL:.+]] = amx.tile_mulf{{.*}}%[[C_TILE]]

/// Consumer uses original C value and the updated one after contraction.
// CHECK: %[[RES_BUF:.+]] = memref.alloca
// CHECK: amx.tile_store %[[RES_BUF]]
// CHECK: %[[RES_VEC:.+]] = vector.transfer_read %[[RES_BUF]]
// CHECK: %[[VEC_MUL:.+]] = arith.mulf %[[C_VEC]], %[[RES_VEC]]

