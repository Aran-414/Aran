
#map = affine_map<(m, n, k, vnni) -> (m, k, vnni)>
#map1 = affine_map<(m, n, k, vnni) -> (k, n, vnni)>
#map2 = affine_map<(m, n, k, vnni) -> (m, n)>
func.func @negative_dynamic_shapes(%A: memref<?x?x?x2xf16>,
    %B: memref<?x?x2xf16>, %C: memref<?x?xf32>, %idx: index) {
  %c0_f16 = arith.constant 0.0 : f16
  %c0_f32 = arith.constant 0.0 : f32
  %vecA = vector.transfer_read %A[%idx, %idx, %idx, %idx], %c0_f16
    {in_bounds = [true, true, true]} : memref<?x?x?x2xf16>, vector<4x8x2xf16>
  %vecB = vector.transfer_read %B[%idx, %idx, %idx], %c0_f16
    {in_bounds = [true, true, true]} : memref<?x?x2xf16>, vector<8x16x2xf16>
  %vecC = vector.transfer_read %C[%idx, %idx], %c0_f32
    {in_bounds = [true, true]} : memref<?x?xf32>, vector<4x16xf32>
  %vecD = vector.contract
    {kind = #vector.kind<add>,
    indexing_maps = [#map, #map1, #map2],
    iterator_types = ["parallel", "parallel", "reduction", "reduction"]}
    %vecA, %vecB, %vecC : vector<4x8x2xf16>, vector<8x16x2xf16> into vector<4x16xf32>
  vector.transfer_write %vecD, %C[%idx, %idx]
    {in_bounds = [true, true]} : vector<4x16xf32>, memref<?x?xf32>
  return
}

// CHECK-LABEL: @negative_dynamic_shapes(
// CHECK-SAME:    %[[A:.+]]: memref<?x?x?x2xf16>,
// CHECK-SAME:    %[[B:.+]]: memref<?x?x2xf16>,
// CHECK-SAME:    %[[C:.+]]: memref<?x?xf32>
// CHECK:  vector.transfer_read %[[A]]
// CHECK:  vector.transfer_read %[[B]]
// CHECK:  vector.transfer_read %[[C]]
// CHECK:  vector.transfer_write{{.*}}%[[C]]

