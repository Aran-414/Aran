
// Unreachable block (and IR in general) is not converted during a dialect
// conversion.

// CHECK-LABEL: func.func @unreachable_block()
//       CHECK:   return
//       CHECK: ^[[bb1:.*]](%[[arg0:.*]]: index):
//       CHECK:   cf.br ^[[bb1]](%[[arg0]] : index)
func.func @unreachable_block() {
  return
^bb1(%arg0: index):
  cf.br ^bb1(%arg0 : index)
}

