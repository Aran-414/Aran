
//   CHECK-LABEL: func.func @multi_case
// CHECK-COUNT-2:   unrealized_conversion_cast {{.*}} : index to i64
//         CHECK:   llvm.switch %{{.*}} : i32, ^{{.*}}(%{{.*}} : i64) [
//         CHECK:     12: ^{{.*}}(%{{.*}} : i64),
//         CHECK:     13: ^{{.*}}(%{{.*}} : i64),
//         CHECK:     14: ^{{.*}}(%{{.*}} : i64)
//         CHECK:   ]
func.func @multi_case(%val: i32, %idx1: index, %idx2: index, %i: i64) -> index {
  cf.switch %val : i32, [
    default: ^bb1(%idx1 : index),
    12: ^bb2(%idx2 : index),
    13: ^bb1(%idx1 : index),
    14: ^bb3(%i : i64)
  ]
^bb1(%arg0: index):
  return %arg0 : index
^bb2(%arg1: index):
  return %arg1 : index
^bb3(%arg2: i64):
  %cast = arith.index_cast %arg2 : i64 to index
  return %cast : index
}
