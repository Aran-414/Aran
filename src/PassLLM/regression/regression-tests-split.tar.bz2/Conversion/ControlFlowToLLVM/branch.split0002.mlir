
// Test case for cf.cond_br.

//   CHECK-LABEL: func.func @cf_cond_br
// CHECK-COUNT-2:   unrealized_conversion_cast {{.*}} : index to i64
//         CHECK:   llvm.cond_br %{{.*}}, ^{{.*}}(%{{.*}} : i64), ^{{.*}}(%{{.*}} : i64)
//         CHECK: ^{{.*}}(%{{.*}}: i64):
//         CHECK:   unrealized_conversion_cast {{.*}} : i64 to index
//         CHECK: ^{{.*}}(%{{.*}}: i64):
//         CHECK:   unrealized_conversion_cast {{.*}} : i64 to index
func.func @cf_cond_br(%cond: i1, %a: index, %b: index) -> index {
  cf.cond_br %cond, ^bb1(%a : index), ^bb2(%b : index)
^bb1(%arg1: index):
  return %arg1 : index
^bb2(%arg2: index):
  return %arg2 : index
}

