// RUN: mlir-opt %s -convert-cf-to-llvm -split-input-file | FileCheck %s

// Unstructured control flow is converted, but the enclosing op is not
// converted.

// CHECK-LABEL: func.func @single_case(
//  CHECK-SAME:     %[[val:.*]]: i32, %[[idx:.*]]: index) -> index {
//       CHECK:   %[[cast0:.*]] = builtin.unrealized_conversion_cast %[[idx]] : index to i64
//       CHECK:   llvm.switch %[[val]] : i32, ^[[bb1:.*]](%[[cast0]] : i64) [
//       CHECK:   ]
//       CHECK: ^[[bb1]](%[[arg0:.*]]: i64):
//       CHECK:   %[[cast1:.*]] = builtin.unrealized_conversion_cast %[[arg0]] : i64 to index
//       CHECK:   return %[[cast1]] : index
//       CHECK: }
func.func @single_case(%val: i32, %idx: index) -> index {
  cf.switch %val : i32, [
    default: ^bb1(%idx : index)
  ]
^bb1(%arg0: index):
  return %arg0 : index
}

