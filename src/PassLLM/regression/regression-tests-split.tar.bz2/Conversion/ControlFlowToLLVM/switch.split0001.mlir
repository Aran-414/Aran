
// func.func and func.return types match. No unrealized_conversion_cast is
// needed.

// CHECK-LABEL: func.func @single_case_type_match(
//  CHECK-SAME:     %[[val:.*]]: i32, %[[i:.*]]: i64) -> i64 {
//       CHECK:   llvm.switch %[[val]] : i32, ^[[bb1:.*]](%[[i]] : i64) [
//       CHECK:   ]
//       CHECK: ^[[bb1]](%[[arg0:.*]]: i64):
//       CHECK:   return %[[arg0]] : i64
//       CHECK: }
func.func @single_case_type_match(%val: i32, %i: i64) -> i64 {
  cf.switch %val : i32, [
    default: ^bb1(%i : i64)
  ]
^bb1(%arg0: i64):
  return %arg0 : i64
}

