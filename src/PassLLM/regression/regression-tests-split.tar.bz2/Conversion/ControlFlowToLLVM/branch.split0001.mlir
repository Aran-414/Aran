
// func.func and func.return types match. No unrealized_conversion_cast is
// needed.

// CHECK-LABEL: func.func @cf_br_type_match(
//  CHECK-SAME:     %[[arg0:.*]]: i64) -> i64 {
//       CHECK:   llvm.br ^[[bb1:.*]](%[[arg0:.*]] : i64)
//       CHECK: ^[[bb1]](%[[arg1:.*]]: i64):
//       CHECK:   return %[[arg1]] : i64
//       CHECK: }
func.func @cf_br_type_match(%arg0: i64) -> i64 {
  cf.br ^bb1(%arg0 : i64)
^bb1(%arg1: i64):
  return %arg1 : i64
}

