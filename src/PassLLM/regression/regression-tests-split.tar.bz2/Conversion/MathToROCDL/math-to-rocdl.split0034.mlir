
// Vector f16 clamp → rocdl.fmed3 on gfx9+
// CHECK-LABEL: func.func @clampf_vector_f16
func.func @clampf_vector_f16(%x: vector<2xf16>, %lo: vector<2xf16>, %hi: vector<2xf16>) -> vector<2xf16> {
  %r = math.clampf %x to [%lo, %hi] : vector<2xf16>
  return %r : vector<2xf16>
  // POST9: rocdl.fmed3 {{.*}} : vector<2xf16>
  // PRE9-NOT: rocdl.fmed3
  // PRE9: math.clampf {{.*}} : vector<2xf16>
}

