// CHECK-LABEL: func.func @clampf_bf16
func.func @clampf_bf16(%x: bf16, %lo: bf16, %hi: bf16) -> bf16 {
  %r = math.clampf %x to [%lo, %hi] : bf16
  return %r : bf16
  // CHECK: math.clampf {{.*}} : bf16
  // CHECK-NOT: rocdl.fmed3
}
