
module @test_module {
  // CHECK: llvm.func @__ocml_exp_f16(f16) -> f16
  // CHECK: llvm.func @__ocml_exp_f64(f64) -> f64
  // CHECK-LABEL: func @math_exp
  func.func @math_exp(%arg_f16 : f16, %arg_f64 : f64) -> (f16, f64) {
    %result16 = math.exp %arg_f16 : f16
    // CHECK: llvm.call @__ocml_exp_f16(%{{.*}}) : (f16) -> f16
    %result64 = math.exp %arg_f64 : f64
    // CHECK: llvm.call @__ocml_exp_f64(%{{.*}}) : (f64) -> f64
    func.return %result16, %result64 : f16, f64
  }
}

