
module @test_module {
  // CHECK: llvm.func @__ocml_sin_f16(f16) -> f16
  // CHECK: llvm.func @__ocml_sin_f32(f32) -> f32
  // CHECK: llvm.func @__ocml_sin_f64(f64) -> f64
  // CHECK-LABEL: func @math_casting
  func.func @math_casting(%arg_f16 : f16, %arg_f32 : f32, %arg_f64 : f64, %arg_bf16 : bf16) -> (f16, f32, f64, bf16) {
    %resultf16 = math.sin %arg_f16 : f16
    // CHECK: llvm.call @__ocml_sin_f16(%{{.*}}) : (f16) -> f16
    %resultf32 = math.sin %arg_f32 : f32
    // CHECK: llvm.call @__ocml_sin_f32(%{{.*}}) : (f32) -> f32
    %resultf64 = math.sin %arg_f64 : f64
    // CHECK: llvm.call @__ocml_sin_f64(%{{.*}}) : (f64) -> f64
    %resultbf16 = math.sin %arg_bf16 : bf16
    // CHECK: llvm.fpext %{{.*}} : bf16 to f32
    // CHECK-NEXT: llvm.call @__ocml_sin_f32(%{{.*}}) : (f32) -> f32
    // CHECK-NEXT: llvm.fptrunc %{{.*}} : f32 to bf16
    func.return %resultf16, %resultf32, %resultf64, %resultbf16 : f16, f32, f64, bf16
  }
}

