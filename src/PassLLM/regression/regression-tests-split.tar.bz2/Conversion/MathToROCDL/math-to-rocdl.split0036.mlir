
// Multi-dimensional vector f16 clamp → rocdl.fmed3 on gfx9+ (unrolled to 1D vectors)
// CHECK-LABEL: func.func @clampf_vector_2d_f16
func.func @clampf_vector_2d_f16(%x: vector<2x2xf16>, %lo: vector<2x2xf16>, %hi: vector<2x2xf16>) -> vector<2x2xf16> {
  %r = math.clampf %x to [%lo, %hi] : vector<2x2xf16>
  return %r : vector<2x2xf16>
  // POST9: builtin.unrealized_conversion_cast {{.*}} : vector<2x2xf16> to !llvm.array<2 x vector<2xf16>>
  // POST9: llvm.extractvalue {{.*}} : !llvm.array<2 x vector<2xf16>>
  // POST9: rocdl.fmed3 {{.*}} : vector<2xf16>
  // POST9: llvm.insertvalue {{.*}} : !llvm.array<2 x vector<2xf16>>
  // POST9: llvm.extractvalue {{.*}} : !llvm.array<2 x vector<2xf16>>
  // POST9: rocdl.fmed3 {{.*}} : vector<2xf16>
  // POST9: llvm.insertvalue {{.*}} : !llvm.array<2 x vector<2xf16>>
  // PRE9-NOT: rocdl.fmed3
  // PRE9: math.clampf {{.*}} : vector<2x2xf16>
}

