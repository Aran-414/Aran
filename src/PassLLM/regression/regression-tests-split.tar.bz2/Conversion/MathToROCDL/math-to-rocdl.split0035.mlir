
// Vector f32 clamp → rocdl.fmed3 on gfx9+
// CHECK-LABEL: func.func @clampf_vector_f32
func.func @clampf_vector_f32(%x: vector<2xf32>, %lo: vector<2xf32>, %hi: vector<2xf32>) -> vector<2xf32> {
  %r = math.clampf %x to [%lo, %hi] : vector<2xf32>
  return %r : vector<2xf32>
  // POST9: rocdl.fmed3 {{.*}} : vector<2xf32>
  // PRE9-NOT: rocdl.fmed3
  // PRE9: math.clampf {{.*}} : vector<2xf32>
}

