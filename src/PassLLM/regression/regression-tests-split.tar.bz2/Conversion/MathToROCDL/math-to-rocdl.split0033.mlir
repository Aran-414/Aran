
// f16 clamp → rocdl.fmed3 on gfx9+
// CHECK-LABEL: func.func @clampf_f16
func.func @clampf_f16(%x: f16, %lo: f16, %hi: f16) -> f16 {
  %r = math.clampf %x to [%lo, %hi] : f16
  return %r : f16
  // POST9: rocdl.fmed3 {{.*}} : f16
  // PRE9-NOT: rocdl.fmed3
  // PRE9: math.clampf {{.*}} : f16
}

// f32 clamp → rocdl.fmed3 on gfx9+
// CHECK-LABEL: func.func @clampf_f32
func.func @clampf_f32(%x: f32, %lo: f32, %hi: f32) -> f32 {
  %r = math.clampf %x to [%lo, %hi] : f32
  return %r : f32
  // POST9: rocdl.fmed3 {{.*}} : f32
  // PRE9-NOT: rocdl.fmed3
  // PRE9: math.clampf {{.*}} : f32
}

