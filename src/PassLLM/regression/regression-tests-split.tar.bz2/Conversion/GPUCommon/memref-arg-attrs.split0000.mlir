// RUN: mlir-opt %s -split-input-file -convert-gpu-to-rocdl='use-bare-ptr-memref-call-conv=0' | FileCheck %s --check-prefixes=CHECK,ROCDL
// RUN: mlir-opt %s -split-input-file -convert-gpu-to-nvvm='use-bare-ptr-memref-call-conv=0' | FileCheck %s --check-prefixes=CHECK,NVVM

gpu.module @kernel {
  gpu.func @test_func_readonly(%arg0 : memref<f32> {llvm.readonly} ) {
    gpu.return
  }
}

// CHECK-LABEL:  llvm.func @test_func_readonly
// ROCDL-SAME:  !llvm.ptr {llvm.readonly}
//  NVVM-SAME:  !llvm.ptr {llvm.readonly}


