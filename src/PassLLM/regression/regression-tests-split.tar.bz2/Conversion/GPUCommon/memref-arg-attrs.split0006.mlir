
gpu.module @kernel {
  gpu.func @test_func_noundef(%arg0 : memref<f32> {llvm.noundef} ) {
    gpu.return
  }
}

// CHECK-LABEL:  llvm.func @test_func_noundef
// ROCDL-SAME:  !llvm.ptr {llvm.noundef}
// ROCDL-SAME:  i64 {llvm.noundef}
//  NVVM-SAME:  !llvm.ptr {llvm.noundef}
//  NVVM-SAME:  i64 {llvm.noundef}
