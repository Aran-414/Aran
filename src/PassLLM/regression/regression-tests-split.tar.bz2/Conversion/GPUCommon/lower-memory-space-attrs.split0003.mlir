
gpu.module @kernel {
  gpu.func @dynamic_shmem_with_vector(%arg1: memref<1xf32>) {
    %0 = arith.constant 0 : index
    %1 = gpu.dynamic_shared_memory : memref<?xi8, #gpu.address_space<workgroup>>
    %2 = memref.view %1[%0][] : memref<?xi8, #gpu.address_space<workgroup>> to memref<1xf32, #gpu.address_space<workgroup>>
    %3 = vector.load %2[%0] : memref<1xf32, #gpu.address_space<workgroup>>, vector<1xf32>
    vector.store %3, %arg1[%0] : memref<1xf32>, vector<1xf32>
    gpu.return
  }
}

// ROCDL: llvm.mlir.global internal @__dynamic_shmem__0() {addr_space = 3 : i32} : !llvm.array<0 x i8>
// NVVM: llvm.mlir.global internal @__dynamic_shmem__0() {addr_space = 3 : i32, alignment = 16 : i64} : !llvm.array<0 x i8>
// CHECK-LABEL:  llvm.func @dynamic_shmem_with_vector
// CHECK: llvm.mlir.addressof @__dynamic_shmem__0 : !llvm.ptr<3>
// CHECK: llvm.load %{{.*}} {alignment = 4 : i64} : !llvm.ptr<3> -> vector<1xf32>
// CHECK: llvm.store

