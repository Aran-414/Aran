
gpu.module @kernel {
  gpu.func @test_func_readonly_ptr(%arg0 : !llvm.ptr {llvm.readonly} ) {
    gpu.return
  }
}

// CHECK-LABEL:  llvm.func @test_func_readonly_ptr
// ROCDL-SAME:  !llvm.ptr {llvm.readonly}
//  NVVM-SAME:  !llvm.ptr {llvm.readonly}

