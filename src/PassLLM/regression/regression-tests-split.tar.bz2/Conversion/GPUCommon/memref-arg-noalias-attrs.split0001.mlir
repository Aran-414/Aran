
gpu.module @kernel {
  gpu.func @func_without_any_attr(%arg0 : memref<f32> ) {
    gpu.return
  }
}

// CHECK-LABEL:  llvm.func @func_without_any_attr
// ROCDL-SAME:  !llvm.ptr
//  NVVM-SAME:  !llvm.ptr
