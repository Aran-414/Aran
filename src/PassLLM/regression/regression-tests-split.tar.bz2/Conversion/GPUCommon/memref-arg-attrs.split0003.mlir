
gpu.module @kernel {
  gpu.func @test_func_nonnull(%arg0 : memref<f32> {llvm.nonnull} ) {
    gpu.return
  }
}

// CHECK-LABEL:  llvm.func @test_func_nonnull
// ROCDL-SAME:  !llvm.ptr {llvm.nonnull}
//  NVVM-SAME:  !llvm.ptr {llvm.nonnull}


