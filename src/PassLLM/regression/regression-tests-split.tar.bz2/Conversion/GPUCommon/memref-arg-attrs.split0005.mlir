
gpu.module @kernel {
  gpu.func @test_func_dereferenceable_or_null(%arg0 : memref<f32> {llvm.dereferenceable_or_null = 4 : i64} ) {
    gpu.return
  }
}

// CHECK-LABEL:  llvm.func @test_func_dereferenceable_or_null
// ROCDL-SAME:  !llvm.ptr {llvm.dereferenceable_or_null = 4 : i64}
//  NVVM-SAME:  !llvm.ptr {llvm.dereferenceable_or_null = 4 : i64}

