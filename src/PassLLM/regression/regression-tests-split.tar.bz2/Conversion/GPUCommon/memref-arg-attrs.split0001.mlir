
gpu.module @kernel {
  gpu.func @test_func_writeonly(%arg0 : memref<f32> {llvm.writeonly} ) {
    gpu.return
  }
}

// CHECK-LABEL:  llvm.func @test_func_writeonly
// ROCDL-SAME:  !llvm.ptr {llvm.writeonly}
//  NVVM-SAME:  !llvm.ptr {llvm.writeonly}

