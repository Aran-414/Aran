
gpu.module @kernel {
  gpu.func @test_func_dereferenceable(%arg0 : memref<f32> {llvm.dereferenceable = 4 : i64} ) {
    gpu.return
  }
}

// CHECK-LABEL:  llvm.func @test_func_dereferenceable
// ROCDL-SAME:  !llvm.ptr {llvm.dereferenceable = 4 : i64}
//  NVVM-SAME:  !llvm.ptr {llvm.dereferenceable = 4 : i64}


