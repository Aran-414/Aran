
func.func @set_max_register() {
  // expected-error @+1 {{new register size must be multiple of 8}}
  nvvm.setmaxregister decrease 51
  func.return
}

