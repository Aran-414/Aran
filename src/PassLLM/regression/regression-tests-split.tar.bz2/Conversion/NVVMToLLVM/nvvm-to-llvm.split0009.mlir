
func.func @cp_async_bulk_commit() {
  // CHECK: nvvm.cp.async.bulk.commit.group
  nvvm.cp.async.bulk.commit.group
  func.return
}

