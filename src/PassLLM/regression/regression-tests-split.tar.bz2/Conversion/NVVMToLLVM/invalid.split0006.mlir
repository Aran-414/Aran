
func.func @wgmma_transpose(%descA : i64, %descB : i64) {  
  %result = llvm.mlir.undef : !llvm.struct<(f16, f16, f16, f16)>
  // expected-error @+1 {{'nvvm.wgmma.mma_async' op f16 += tf32 * tf32, it is not supported.}}
  %res = nvvm.wgmma.mma_async %descA, %descB, %result,
      #nvvm.shape<m = 64, n = 16, k = 8>, 
      D [<f16>, <zero>], 
      A [<tf32>, #nvvm.wgmma_scale_in<neg>, <col>], 
      B [<tf32>, #nvvm.wgmma_scale_in<neg>, <col>]
      :!llvm.struct<(f16, f16, f16, f16)>
      -> !llvm.struct<(f16, f16, f16, f16)>
  return 
}

