
func.func @fence_proxy() {
  // expected-error @+1 {{op async_shared fence requires space attribute}}
  nvvm.fence.proxy { kind = #nvvm.proxy_kind<async.shared>}
  func.return
}
