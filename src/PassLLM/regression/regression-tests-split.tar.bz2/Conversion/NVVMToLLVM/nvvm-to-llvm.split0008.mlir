
func.func @set_max_register() {
  // CHECK: nvvm.setmaxregister increase 232
  nvvm.setmaxregister increase 232

  // CHECK: nvvm.setmaxregister decrease 40
  nvvm.setmaxregister decrease 40
  func.return
}

