
func.func @set_max_register() {
  // expected-error @+1 {{new register size must be in between 24 to 256}}
  nvvm.setmaxregister decrease 8
  func.return
}

