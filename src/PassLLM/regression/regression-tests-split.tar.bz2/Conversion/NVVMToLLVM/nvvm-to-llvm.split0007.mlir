
// CHECK-LABEL: @test_nvvm_prefetch
llvm.func @test_nvvm_prefetch(%desc : !llvm.ptr, %pred : i1) {
  //CHECK: nvvm.prefetch tensormap, %{{.*}}
  nvvm.prefetch tensormap, %desc : !llvm.ptr
  //CHECK: llvm.inline_asm has_side_effects asm_dialect = att "@$1 prefetch.tensormap [$0];", "l,b"
  nvvm.prefetch tensormap, %desc, predicate = %pred : !llvm.ptr, i1
  llvm.return
}

