
func.func @elect_one_leader_sync() {  
  // CHECK: %[[RES:.*]] = nvvm.elect.sync -> i1
  %cnd = nvvm.elect.sync -> i1 
  return 
}

