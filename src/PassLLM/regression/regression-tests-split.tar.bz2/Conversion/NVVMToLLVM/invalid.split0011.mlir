
func.func @fence_proxy() {
  // expected-error @+1 {{op only async_shared fence can have space attribute}}
  nvvm.fence.proxy { kind = #nvvm.proxy_kind<async>, space = #nvvm.shared_space<cluster>}
  func.return
}

