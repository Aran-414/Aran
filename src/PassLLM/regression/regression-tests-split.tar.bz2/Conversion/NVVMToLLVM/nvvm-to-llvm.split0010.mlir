
func.func @cp_async_bulk_wait_group() {
  // CHECK: nvvm.cp.async.bulk.wait_group 1
  // CHECK: nvvm.cp.async.bulk.wait_group 0
  // CHECK: nvvm.cp.async.bulk.wait_group 5 {read}
  // CHECK: nvvm.cp.async.bulk.wait_group 0 {read}
  nvvm.cp.async.bulk.wait_group 1
  nvvm.cp.async.bulk.wait_group 0
  nvvm.cp.async.bulk.wait_group 5 {read}
  nvvm.cp.async.bulk.wait_group 0 {read}
  func.return
}

