
// Handle blocks whose arguments require type conversion.

// CHECK-LABEL: func.func @main_graph
func.func @main_graph(%arg0: index) {
  %c3 = arith.constant 1 : index
// CHECK:  spirv.Branch ^bb1({{.*}} : i32)
  cf.br ^bb1(%arg0 : index)
// CHECK:      ^bb1({{.*}}: i32):       // 2 preds: ^bb0, ^bb2
^bb1(%0: index):  // 2 preds: ^bb0, ^bb2
  %1 = arith.cmpi slt, %0, %c3 : index
// CHECK:        spirv.BranchConditional {{.*}}, ^bb2, ^bb3
  cf.cond_br %1, ^bb2, ^bb3
^bb2:  // pred: ^bb1
// CHECK:  spirv.Branch ^bb1({{.*}} : i32)
  cf.br ^bb1(%c3 : index)
^bb3:  // pred: ^bb1
  return
}
