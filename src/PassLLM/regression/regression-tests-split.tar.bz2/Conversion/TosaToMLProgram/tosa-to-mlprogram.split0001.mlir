
module {
  // CHECK: ml_program.global private mutable @var_x : tensor<f32>
  tosa.variable @var_x : tensor<f32>
  func.func @test_stateful_ops(%arg0: tensor<f32>) -> (tensor<f32>) {
    // CHECK: ml_program.global_store @var_x = %arg0 : tensor<f32>
    tosa.variable_write @var_x, %arg0 : tensor<f32>
    // CHECK: %[[LOAD:.+]] = ml_program.global_load @var_x : tensor<f32>
    %0 = tosa.variable_read @var_x : tensor<f32>
    return %0 : tensor<f32>
  }
}
