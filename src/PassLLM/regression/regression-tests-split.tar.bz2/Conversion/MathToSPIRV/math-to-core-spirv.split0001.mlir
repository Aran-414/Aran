
module attributes { spirv.target_env = #spirv.target_env<#spirv.vce<v1.0, [Float16, Int16], []>, #spirv.resource_limits<>> } {

func.func @copy_sign_vector(%value: vector<3xf16>, %sign: vector<3xf16>) -> vector<3xf16> {
  %0 = math.copysign %value, %sign : vector<3xf16>
  return %0: vector<3xf16>
}

}

// CHECK-LABEL: func @copy_sign_vector
//  CHECK-SAME: (%[[VALUE:.+]]: vector<3xf16>, %[[SIGN:.+]]: vector<3xf16>)
//       CHECK:   %[[SMASK:.+]] = spirv.Constant -32768 : i16
//       CHECK:   %[[VMASK:.+]] = spirv.Constant 32767 : i16
//       CHECK:   %[[SVMASK:.+]] = spirv.CompositeConstruct %[[SMASK]], %[[SMASK]], %[[SMASK]]
//       CHECK:   %[[VVMASK:.+]] = spirv.CompositeConstruct %[[VMASK]], %[[VMASK]], %[[VMASK]]
//       CHECK:   %[[VCAST:.+]] = spirv.Bitcast %[[VALUE]] : vector<3xf16> to vector<3xi16>
//       CHECK:   %[[SCAST:.+]] = spirv.Bitcast %[[SIGN]] : vector<3xf16> to vector<3xi16>
//       CHECK:   %[[VAND:.+]] = spirv.BitwiseAnd %[[VCAST]], %[[VVMASK]] : vector<3xi16>
//       CHECK:   %[[SAND:.+]] = spirv.BitwiseAnd %[[SCAST]], %[[SVMASK]] : vector<3xi16>
//       CHECK:   %[[OR:.+]] = spirv.BitwiseOr %[[VAND]], %[[SAND]] : vector<3xi16>
//       CHECK:   %[[RESULT:.+]] = spirv.Bitcast %[[OR]] : vector<3xi16> to vector<3xf16>
//       CHECK:   return %[[RESULT]]

