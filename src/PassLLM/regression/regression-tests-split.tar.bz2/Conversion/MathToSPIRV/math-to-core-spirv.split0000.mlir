// RUN: mlir-opt -split-input-file -convert-math-to-spirv -verify-diagnostics %s -o - | FileCheck %s

func.func @copy_sign_scalar(%value: f32, %sign: f32) -> f32 {
  %0 = math.copysign %value, %sign : f32
  return %0: f32
}

// CHECK-LABEL: func @copy_sign_scalar
//  CHECK-SAME: (%[[VALUE:.+]]: f32, %[[SIGN:.+]]: f32)
//       CHECK:   %[[SMASK:.+]] = spirv.Constant -2147483648 : i32
//       CHECK:   %[[VMASK:.+]] = spirv.Constant 2147483647 : i32
//       CHECK:   %[[VCAST:.+]] = spirv.Bitcast %[[VALUE]] : f32 to i32
//       CHECK:   %[[SCAST:.+]] = spirv.Bitcast %[[SIGN]] : f32 to i32
//       CHECK:   %[[VAND:.+]] = spirv.BitwiseAnd %[[VCAST]], %[[VMASK]] : i32
//       CHECK:   %[[SAND:.+]] = spirv.BitwiseAnd %[[SCAST]], %[[SMASK]] : i32
//       CHECK:   %[[OR:.+]] = spirv.BitwiseOr %[[VAND]], %[[SAND]] : i32
//       CHECK:   %[[RESULT:.+]] = spirv.Bitcast %[[OR]] : i32 to f32
//       CHECK:   return %[[RESULT]]

