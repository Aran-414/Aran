
// Tensors are not supported.
func.func @copy_sign_tensor(%value: tensor<3x3xf32>, %sign: tensor<3x3xf32>) -> tensor<3x3xf32> {
  %0 = math.copysign %value, %sign : tensor<3x3xf32>
  return %0: tensor<3x3xf32>
}

// CHECK-LABEL: func @copy_sign_tensor
// CHECK-NEXT:    math.copysign {{%.+}}, {{%.+}} : tensor<3x3xf32>
// CHECK-NEXT:    return
