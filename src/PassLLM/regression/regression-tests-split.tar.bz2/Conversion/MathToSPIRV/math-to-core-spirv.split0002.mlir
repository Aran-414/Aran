
// 2-D vectors are not supported.
func.func @copy_sign_2d_vector(%value: vector<3x3xf32>, %sign: vector<3x3xf32>) -> vector<3x3xf32> {
  %0 = math.copysign %value, %sign : vector<3x3xf32>
  return %0: vector<3x3xf32>
}

// CHECK-LABEL: func @copy_sign_2d_vector
// CHECK-NEXT:    math.copysign {{%.+}}, {{%.+}} : vector<3x3xf32>
// CHECK-NEXT:    return

