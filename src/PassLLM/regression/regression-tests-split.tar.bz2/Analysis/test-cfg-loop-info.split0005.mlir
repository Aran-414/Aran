
// CHECK-LABEL: Testing : "multi_latch"
// CHECK-NEXT: Blocks : ^[[BB0:.*]], ^[[BB1:.*]], ^[[BB2:.*]], ^[[BB3:.*]], ^[[BB4:.*]]
// CHECK: Loop at depth 1
// CHECK-SAME: ^[[BB1]]<header><exiting>
// CHECK-SAME: ^[[BB2]]<latch>
// CHECK-SAME: ^[[BB3]]<latch>
func.func @multi_latch(%c: i1) {
  cf.br ^bb1
^bb1:
  cf.cond_br %c, ^bb4, ^bb2
^bb2:
  cf.cond_br %c, ^bb1, ^bb3
^bb3:
  cf.br ^bb1
^bb4:
  return
}

