// RUN: mlir-opt %s -pass-pipeline="builtin.module(func.func(test-print-dominance))" -split-input-file | FileCheck %s

// CHECK-LABEL: Testing : func_condBranch
func.func @func_condBranch(%cond : i1) {
  cf.cond_br %cond, ^bb1, ^bb2
^bb1:
  cf.br ^exit
^bb2:
  cf.br ^exit
^exit:
  return
}

// CHECK: --- DominanceInfo ---
// CHECK: Nearest(0, 0) = 0
// CHECK: Nearest(0, 1) = 0
// CHECK: Nearest(0, 2) = 0
// CHECK: Nearest(0, 3) = 0
// CHECK: Nearest(0, 4) = 4
// CHECK: Nearest(1, 0) = 0
// CHECK: Nearest(1, 1) = 1
// CHECK: Nearest(1, 2) = 0
// CHECK: Nearest(1, 3) = 0
// CHECK: Nearest(1, 4) = 4
// CHECK: Nearest(2, 0) = 0
// CHECK: Nearest(2, 1) = 0
// CHECK: Nearest(2, 2) = 2
// CHECK: Nearest(2, 3) = 0
// CHECK: Nearest(2, 4) = 4
// CHECK: Nearest(3, 0) = 0
// CHECK: Nearest(3, 1) = 0
// CHECK: Nearest(3, 2) = 0
// CHECK: Nearest(3, 3) = 3
// CHECK: Nearest(3, 4) = 4
// CHECK: Nearest(4, 0) = 4
// CHECK: Nearest(4, 1) = 4
// CHECK: Nearest(4, 2) = 4
// CHECK: Nearest(4, 3) = 4
// CHECK: Nearest(4, 4) = 4

// CHECK: --- PostDominanceInfo ---
// CHECK: Nearest(0, 0) = 0
// CHECK: Nearest(0, 1) = 3
// CHECK: Nearest(0, 2) = 3
// CHECK: Nearest(0, 3) = 3
// CHECK: Nearest(0, 4) = 4
// CHECK: Nearest(1, 0) = 3
// CHECK: Nearest(1, 1) = 1
// CHECK: Nearest(1, 2) = 3
// CHECK: Nearest(1, 3) = 3
// CHECK: Nearest(1, 4) = 4
// CHECK: Nearest(2, 0) = 3
// CHECK: Nearest(2, 1) = 3
// CHECK: Nearest(2, 2) = 2
// CHECK: Nearest(2, 3) = 3
// CHECK: Nearest(2, 4) = 4
// CHECK: Nearest(3, 0) = 3
// CHECK: Nearest(3, 1) = 3
// CHECK: Nearest(3, 2) = 3
// CHECK: Nearest(3, 3) = 3
// CHECK: Nearest(3, 4) = 4
// CHECK: Nearest(4, 0) = 4
// CHECK: Nearest(4, 1) = 4
// CHECK: Nearest(4, 2) = 4
// CHECK: Nearest(4, 3) = 4
// CHECK: Nearest(4, 4) = 4

// CHECK: --- Block Dominance relationship ---
// CHECK: dominates(0, 0) = 1 (properly = 0)
// CHECK: dominates(0, 1) = 1 (properly = 1)
// CHECK: dominates(0, 2) = 1 (properly = 1)
// CHECK: dominates(0, 3) = 1 (properly = 1)
// CHECK: dominates(0, 4) = 0 (properly = 0)
// CHECK: dominates(1, 0) = 0 (properly = 0)
// CHECK: dominates(1, 1) = 1 (properly = 0)
// CHECK: dominates(1, 2) = 0 (properly = 0)
// CHECK: dominates(1, 3) = 0 (properly = 0)
// CHECK: dominates(1, 4) = 0 (properly = 0)
// CHECK: dominates(2, 0) = 0 (properly = 0)
// CHECK: dominates(2, 1) = 0 (properly = 0)
// CHECK: dominates(2, 2) = 1 (properly = 0)
// CHECK: dominates(2, 3) = 0 (properly = 0)
// CHECK: dominates(2, 4) = 0 (properly = 0)
// CHECK: dominates(3, 0) = 0 (properly = 0)
// CHECK: dominates(3, 1) = 0 (properly = 0)
// CHECK: dominates(3, 2) = 0 (properly = 0)
// CHECK: dominates(3, 3) = 1 (properly = 0)
// CHECK: dominates(3, 4) = 0 (properly = 0)
// CHECK: dominates(4, 0) = 1 (properly = 1)
// CHECK: dominates(4, 1) = 1 (properly = 1)
// CHECK: dominates(4, 2) = 1 (properly = 1)
// CHECK: dominates(4, 3) = 1 (properly = 1)
// CHECK: dominates(4, 4) = 1 (properly = 1)

// CHECK: --- Block PostDominance relationship ---
// CHECK: postdominates(0, 0) = 1 (properly = 0)
// CHECK: postdominates(0, 1) = 0 (properly = 0)
// CHECK: postdominates(0, 2) = 0 (properly = 0)
// CHECK: postdominates(0, 3) = 0 (properly = 0)
// CHECK: postdominates(0, 4) = 0 (properly = 0)
// CHECK: postdominates(1, 0) = 0 (properly = 0)
// CHECK: postdominates(1, 1) = 1 (properly = 0)
// CHECK: postdominates(1, 2) = 0 (properly = 0)
// CHECK: postdominates(1, 3) = 0 (properly = 0)
// CHECK: postdominates(1, 4) = 0 (properly = 0)
// CHECK: postdominates(2, 0) = 0 (properly = 0)
// CHECK: postdominates(2, 1) = 0 (properly = 0)
// CHECK: postdominates(2, 2) = 1 (properly = 0)
// CHECK: postdominates(2, 3) = 0 (properly = 0)
// CHECK: postdominates(2, 4) = 0 (properly = 0)
// CHECK: postdominates(3, 0) = 1 (properly = 1)
// CHECK: postdominates(3, 1) = 1 (properly = 1)
// CHECK: postdominates(3, 2) = 1 (properly = 1)
// CHECK: postdominates(3, 3) = 1 (properly = 0)
// CHECK: postdominates(3, 4) = 0 (properly = 0)
// CHECK: postdominates(4, 0) = 1 (properly = 1)
// CHECK: postdominates(4, 1) = 1 (properly = 1)
// CHECK: postdominates(4, 2) = 1 (properly = 1)
// CHECK: postdominates(4, 3) = 1 (properly = 1)
// CHECK: postdominates(4, 4) = 1 (properly = 1)

// CHECK: module attributes {test.block_ids = array<i64: 4>}
// CHECK:   func.func @func_condBranch({{.*}}) attributes {test.block_ids = array<i64: 0, 1, 2, 3>}

