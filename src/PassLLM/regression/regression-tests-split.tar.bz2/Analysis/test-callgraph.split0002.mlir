
// CHECK-LABEL: Testing : "SCC"
// CHECK: SCCs
module attributes {test.name = "SCC"} {
  // CHECK: SCC :
  // CHECK-NEXT: Node{{.*}}Unknown-Callee-Node

  // CHECK: SCC :
  // CHECK-NEXT: Node{{.*}}foo
  func.func @foo(%arg0 : () -> ()) {
    call_indirect %arg0() : () -> ()
    return
  }

  // CHECK: SCC :
  // CHECK-NEXT: Node{{.*}}bar
  func.func @bar(%arg1 : () -> ()) {
    call_indirect %arg1() : () -> ()
    return
  }

  // CHECK: SCC :
  // CHECK-NEXT: Node{{.*}}External-Caller-Node
}

