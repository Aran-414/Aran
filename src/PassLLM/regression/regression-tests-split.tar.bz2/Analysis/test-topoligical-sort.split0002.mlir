
// CHECK-LABEL: @multi_region
func.func @multi_region(%cond: i1) {
  scf.if %cond {
    // CHECK: test_sort_index = 0
    %0 = arith.constant {test_to_sort} 42 : i32
  }

  scf.if %cond {
    // CHECK: test_sort_index = 1
    %0 = arith.constant {test_to_sort} 24 : i32
  }
  return
}
