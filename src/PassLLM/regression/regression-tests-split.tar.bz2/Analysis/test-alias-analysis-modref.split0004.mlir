
// CHECK-LABEL: Testing : "unknown"
// CHECK-DAG: unknown -> func.region0#0: ModRef
func.func @unknown(%arg0: memref<i32>) attributes {test.ptr = "func"} {
  "foo.op"() {test.ptr = "unknown"} : () -> ()
  return
}
