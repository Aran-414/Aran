
// CHECK-LABEL: function: @test_simple_loop
func.func @test_simple_loop() -> () {
  // CHECK: init -> 1
  "test.branch"() [^bb0] {tag = "init", foo = 1 : ui64} : () -> ()

^bb0:
  // CHECK: a -> 1
  "test.foo"() {tag = "a", foo = 3 : ui64} : () -> ()
  "test.branch"() [^bb0, ^bb1] : () -> ()

^bb1:
  // CHECK: end -> 3
  "test.foo"() {tag = "end"} : () -> ()
  return
}

