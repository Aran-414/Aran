
// CHECK-LABEL: function: @test_two_join
func.func @test_two_join() -> () {
  // CHECK: a -> 0
  "test.foo"() {tag = "a"} : () -> ()
  // CHECK: b -> 1
  "test.foo"() {tag = "b", foo = 1 : ui64} : () -> ()
  // CHECK: c -> 0
  "test.foo"() {tag = "c", foo = 1 : ui64} : () -> ()
  return
}

