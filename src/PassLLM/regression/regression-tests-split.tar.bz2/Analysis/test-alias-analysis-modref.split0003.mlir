
// CHECK-LABEL: Testing : "recursive"
// CHECK-DAG: if -> func.region0#0: ModRef
// CHECK-DAG: if -> func.region0#1: ModRef

// TODO: This is provably NoModRef, but requires handling recursive side
// effects.
// CHECK-DAG: if -> alloc#0: ModRef
func.func @recursive(%arg0: memref<i32>, %arg1: memref<i32>, %cond: i1, %value: i32) attributes {test.ptr = "func"} {
  %0 = memref.alloca() {test.ptr = "alloc"} : memref<i32>
  scf.if %cond {
    memref.store %value, %arg0[] : memref<i32>
    %1 = memref.load %arg0[] : memref<i32>
  } {test.ptr = "if"}
  return {test.ptr = "return"}
}

