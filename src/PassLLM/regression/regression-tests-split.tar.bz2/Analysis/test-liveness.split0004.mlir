
// CHECK-LABEL: Testing : func_ranges
func.func @func_ranges(%cond : i1, %arg1 : i32, %arg2 : i32, %arg3 : i32) -> i32 {
  // CHECK: Block: 0
  // CHECK-NEXT: LiveIn:{{ *$}}
  // CHECK-NEXT: LiveOut: arg2@0 val_9 val_10
  // CHECK-NEXT: BeginLivenessIntervals
  // CHECK-NEXT: val_4
  // CHECK-NEXT:    %0 = arith.addi
  // CHECK-NEXT:    %c
  // CHECK-NEXT:    %1 = arith.addi
  // CHECK-NEXT:    %2 = arith.addi
  // CHECK-NEXT:    %3 = arith.muli
  // CHECK-NEXT: val_5
  // CHECK-NEXT:    %c
  // CHECK-NEXT:    %1 = arith.addi
  // CHECK-NEXT:    %2 = arith.addi
  // CHECK-NEXT:    %3 = arith.muli
  // CHECK-NEXT:    %4 = arith.muli
  // CHECK-NEXT:    %5 = arith.addi
  // CHECK-NEXT: val_6
  // CHECK-NEXT:    %1 = arith.addi
  // CHECK-NEXT:    %2 = arith.addi
  // CHECK-NEXT:    %3 = arith.muli
  // CHECK-NEXT: val_7
  // CHECK-NEXT:   %2 = arith.addi
  // CHECK-NEXT:   %3 = arith.muli
  // CHECK-NEXT:   %4 = arith.muli
  // CHECK:      val_8
  // CHECK-NEXT:    %3 = arith.muli
  // CHECK-NEXT:    %4 = arith.muli
  // CHECK-NEXT: val_9
  // CHECK-NEXT:    %4 = arith.muli
  // CHECK-NEXT:    %5 = arith.addi
  // CHECK-NEXT:    cf.cond_br
  // CHECK-NEXT:    %c
  // CHECK-NEXT:    %6 = arith.muli
  // CHECK-NEXT:    %7 = arith.muli
  // CHECK-NEXT:    %8 = arith.addi
  // CHECK-NEXT: val_10
  // CHECK-NEXT:    %5 = arith.addi
  // CHECK-NEXT:    cf.cond_br
  // CHECK-NEXT:    %7
  // CHECK: EndLivenessIntervals
  // CHECK-NEXT: BeginCurrentlyLive
  // CHECK: arith.addi
  // CHECK-SAME:  arg0@0 arg1@0 arg2@0 arg3@0 val_4
  // CHECK: arith.constant
  // CHECK-SAME:  arg0@0 arg2@0 arg3@0 val_4 val_5
  // CHECK: arith.addi
  // CHECK-SAME:  arg0@0 arg2@0 arg3@0 val_4 val_5 val_6
  // CHECK: arith.addi
  // CHECK-SAME:  arg0@0 arg2@0 arg3@0 val_4 val_5 val_6 val_7
  // CHECK: arith.muli
  // CHECK-SAME:  arg0@0 arg2@0 val_4 val_5 val_6 val_7 val_8
  // CHECK: arith.muli
  // CHECK-SAME:  arg0@0 arg2@0 val_5 val_7 val_8 val_9
  // CHECK: arith.addi
  // CHECK-SAME:  arg0@0 arg2@0 val_5 val_9 val_10
  // CHECK: cf.cond_br
  // CHECK-SAME:  arg0@0 arg2@0 val_9 val_10
  // CHECK-NEXT: EndCurrentlyLive
  %0 = arith.addi %arg1, %arg2 : i32
  %const1 = arith.constant 1 : i32
  %1 = arith.addi %const1, %arg2 : i32
  %2 = arith.addi %const1, %arg3 : i32
  %3 = arith.muli %0, %1 : i32
  %4 = arith.muli %3, %2 : i32
  %5 = arith.addi %4, %const1 : i32
  cf.cond_br %cond, ^bb1, ^bb2

^bb1:
  // CHECK: Block: 1
  // CHECK-NEXT: LiveIn: arg2@0 val_9
  // CHECK-NEXT: LiveOut: arg2@0
  // CHECK: BeginCurrentlyLive
  // CHECK: arith.constant
  // CHECK-SAME:  arg2@0 val_9
  // CHECK: arith.muli
  // CHECK-SAME:  arg2@0 val_9
  // CHECK: cf.br
  // CHECK-SAME:  arg2@0
  // CHECK-NEXT: EndCurrentlyLive
  %const4 = arith.constant 4 : i32
  %6 = arith.muli %4, %const4 : i32
  cf.br ^exit(%6 : i32)

^bb2:
  // CHECK: Block: 2
  // CHECK-NEXT: LiveIn: arg2@0 val_9 val_10
  // CHECK-NEXT: LiveOut: arg2@0
  // CHECK: BeginCurrentlyLive
  // CHECK: arith.muli
  // CHECK-SAME:  arg2@0 val_9 val_10
  // CHECK: arith.addi
  // CHECK-SAME:  arg2@0
  // CHECK: cf.br
  // CHECK-SAME:  arg2@0
  // CHECK: EndCurrentlyLive
  %7 = arith.muli %4, %5 : i32
  %8 = arith.addi %4, %arg2 : i32
  cf.br ^exit(%8 : i32)

^exit(%sum : i32):
  // CHECK: Block: 3
  // CHECK-NEXT: LiveIn: arg2@0
  // CHECK-NEXT: LiveOut:{{ *$}}
  // CHECK: BeginCurrentlyLive
  // CHECK: arith.addi
  // CHECK-SAME:  arg2@0
  // CHECK: return
  // CHECK-NOT: arg2@0
  // CHECK: EndCurrentlyLive
  %result = arith.addi %sum, %arg2 : i32
  return %result : i32
}

