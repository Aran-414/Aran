
// CHECK-LABEL: function: @test_double_loop
func.func @test_double_loop() -> () {
  // CHECK: init -> 2
  "test.branch"() [^bb0] {tag = "init", foo = 2 : ui64} : () -> ()

^bb0:
  // CHECK: a -> 1
  "test.foo"() {tag = "a", foo = 3 : ui64} : () -> ()
  "test.branch"() [^bb0, ^bb1] : () -> ()

^bb1:
  // CHECK: b -> 4
  "test.foo"() {tag = "b", foo = 5 : ui64} : () -> ()
  "test.branch"() [^bb0, ^bb2] : () -> ()

^bb2:
  // CHECK: end -> 4
  "test.foo"() {tag = "end"} : () -> ()
  return
}
