
// CHECK-LABEL: Testing : "multiple_loops"
// CHECK-NEXT: Blocks : ^[[BB0:.*]], ^[[BB1:.*]], ^[[BB2:.*]], ^[[BB3:.*]], ^[[BB4:.*]], ^[[BB5:.*]]
// CHECK: Loop at depth 1
// CHECK-SAME: ^[[BB3]]<header><exiting>
// CHECK-SAME: ^[[BB4]]<latch>
// CHECK: Loop at depth 1
// CHECK-SAME: ^[[BB1]]<header>
// CHECK-SAME: ^[[BB2]]<latch><exiting>
func.func @multiple_loops(%c: i1) {
  cf.br ^bb1
^bb1:
  cf.br ^bb2
^bb2:
  cf.cond_br %c, ^bb3, ^bb1
^bb3:
  cf.cond_br %c, ^bb5, ^bb4
^bb4:
  cf.br ^bb3
^bb5:
  return
}
