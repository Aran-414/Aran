
// expected-remark@below {{Testing function}}
func.func @linalg_fused_red_add(%in0t: tensor<4x4xf32>, %out0t: tensor<4xf32>) {
  // expected-remark@below {{Reduction found in output #0!}}
  // expected-remark@below {{Reduced Value: %2 = arith.subf}}
  // expected-remark@below {{Combiner Op: %3 = arith.addf}}
  %red = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>,
                                          affine_map<(d0, d1) -> (d0)>],
   iterator_types = ["parallel", "reduction"]}
   ins(%in0t : tensor<4x4xf32>)
   outs(%out0t : tensor<4xf32>) {
    ^bb0(%in0: f32, %out0: f32):
      %mul = arith.mulf %in0, %in0 : f32
      %sub = arith.subf %mul, %in0 : f32
      %add = arith.addf %sub, %out0 : f32
      linalg.yield %add : f32
    } -> tensor<4xf32>
  return
}

