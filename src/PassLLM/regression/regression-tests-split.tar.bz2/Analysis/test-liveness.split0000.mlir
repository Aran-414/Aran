// RUN: mlir-opt %s -pass-pipeline="builtin.module(func.func(test-print-liveness))" -split-input-file 2>&1 | FileCheck %s

// CHECK-LABEL: Testing : func_empty
func.func @func_empty() {
  // CHECK: Block: 0
  // CHECK-NEXT: LiveIn:{{ *$}}
  // CHECK-NEXT: LiveOut:{{ *$}}
  // CHECK-NEXT: BeginLivenessIntervals
  // CHECK-NEXT: EndLivenessIntervals
  // CHECK-NEXT: BeginCurrentlyLive
  // CHECK-NEXT: EndCurrentlyLive
  return
}

