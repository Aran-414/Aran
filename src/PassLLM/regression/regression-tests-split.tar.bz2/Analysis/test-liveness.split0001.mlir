
// CHECK-LABEL: Testing : func_simpleBranch
func.func @func_simpleBranch(%arg0: i32, %arg1 : i32) -> i32 {
  // CHECK: Block: 0
  // CHECK-NEXT: LiveIn:{{ *$}}
  // CHECK-NEXT: LiveOut: arg0@0 arg1@0
  // CHECK-NEXT: BeginLivenessIntervals
  // CHECK-NEXT: EndLivenessIntervals
  // CHECK-NEXT: BeginCurrentlyLive
  // CHECK: cf.br
  // CHECK-SAME:   arg0@0 arg1@0
  // CHECK-NEXT: EndCurrentlyLive
  cf.br ^exit
^exit:
  // CHECK: Block: 1
  // CHECK-NEXT: LiveIn: arg0@0 arg1@0
  // CHECK-NEXT: LiveOut:{{ *$}}
  // CHECK-NEXT: BeginLivenessIntervals
  // CHECK: val_2
  // CHECK-NEXT:     %0 = arith.addi
  // CHECK-NEXT:     return
  // CHECK-NEXT: EndLivenessIntervals
  // CHECK-NEXT: BeginCurrentlyLive
  // CHECK: arith.addi
  // CHECK-SAME:    arg0@0 arg1@0 val_2
  // CHECK: return
  // CHECK-SAME:    val_2
  // CHECK-NEXT:EndCurrentlyLive
  %result = arith.addi %arg0, %arg1 : i32
  return %result : i32
}

