
// expected-remark@below {{Testing function}}
func.func @affine_output_dep(%in: memref<512xf32>) {
 %cst = arith.constant 0.000000e+00 : f32
 // Reduction %red is not supported because it depends on another
 // loop-carried dependence.
 // expected-remark@below {{Reduction NOT found in output #0!}}
 // expected-remark@below {{Reduction NOT found in output #1!}}
 %final_red, %final_dep = affine.for %j = 0 to 512
  iter_args(%red = %cst, %dep = %cst) -> (f32, f32) {
   %ld = affine.load %in[%j] : memref<512xf32>
   %add = arith.addf %dep, %red : f32
   affine.yield %add, %ld : f32, f32
 }
 return
}

