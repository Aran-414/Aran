// RUN: mlir-opt %s -pass-pipeline="builtin.module(func.func(test-match-reduction))" -verify-diagnostics -split-input-file

// Verify that the generic reduction detection utility works on different
// dialects.

// expected-remark@below {{Testing function}}
func.func @linalg_red_add(%in0t : tensor<?xf32>, %out0t : tensor<1xf32>) {
  // expected-remark@below {{Reduction found in output #0!}}
  // expected-remark@below {{Reduced Value: <block argument> of type 'f32' at index: 0}}
  // expected-remark@below {{Combiner Op: %1 = arith.addf }}
  %red = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>,
                                          affine_map<(d0) -> (0)>],
                                          iterator_types = ["reduction"]}
   ins(%in0t : tensor<?xf32>)
   outs(%out0t : tensor<1xf32>) {
    ^bb0(%in0: f32, %out0: f32):
      %add = arith.addf %in0, %out0 : f32
      linalg.yield %add : f32
    } -> tensor<1xf32>
  return
}

