
// CHECK-LABEL: Testing : nested_region
func.func @nested_region(%arg0 : index, %arg1 : index, %arg2 : index) {
  scf.for %arg3 = %arg0 to %arg1 step %arg2 { }
  return
}

// CHECK: --- DominanceInfo ---
// CHECK: Nearest(0, 0) = 0
// CHECK: Nearest(0, 1) = 1
// CHECK: Nearest(0, 2) = 2
// CHECK: Nearest(1, 0) = 1
// CHECK: Nearest(1, 1) = 1
// CHECK: Nearest(1, 2) = 2
// CHECK: Nearest(2, 0) = 2
// CHECK: Nearest(2, 1) = 2
// CHECK: Nearest(2, 2) = 2

// CHECK: --- PostDominanceInfo ---
// CHECK: Nearest(0, 0) = 0
// CHECK: Nearest(0, 1) = 1
// CHECK: Nearest(0, 2) = 2
// CHECK: Nearest(1, 0) = 1
// CHECK: Nearest(1, 1) = 1
// CHECK: Nearest(1, 2) = 2
// CHECK: Nearest(2, 0) = 2
// CHECK: Nearest(2, 1) = 2
// CHECK: Nearest(2, 2) = 2

// CHECK: --- Block Dominance relationship ---
// CHECK: dominates(0, 0) = 1 (properly = 0)
// CHECK: dominates(0, 1) = 0 (properly = 0)
// CHECK: dominates(0, 2) = 0 (properly = 0)
// CHECK: dominates(1, 0) = 1 (properly = 1)
// CHECK: dominates(1, 1) = 1 (properly = 0)
// CHECK: dominates(1, 2) = 0 (properly = 0)
// CHECK: dominates(2, 0) = 1 (properly = 1)
// CHECK: dominates(2, 1) = 1 (properly = 1)
// CHECK: dominates(2, 2) = 1 (properly = 1)

// CHECK: --- Block PostDominance relationship ---
// CHECK: postdominates(0, 0) = 1 (properly = 0)
// CHECK: postdominates(0, 1) = 0 (properly = 0)
// CHECK: postdominates(0, 2) = 0 (properly = 0)
// CHECK: postdominates(1, 0) = 1 (properly = 1)
// CHECK: postdominates(1, 1) = 1 (properly = 0)
// CHECK: postdominates(1, 2) = 0 (properly = 0)
// CHECK: postdominates(2, 0) = 1 (properly = 1)
// CHECK: postdominates(2, 1) = 1 (properly = 1)
// CHECK: postdominates(2, 2) = 1 (properly = 1)

// CHECK: module attributes {test.block_ids = array<i64: 2>} {
// CHECK:   func.func @nested_region({{.*}}) attributes {test.block_ids = array<i64: 1>} {
// CHECK:     scf.for {{.*}} {
// CHECK:     } {test.block_ids = array<i64: 0>}
// CHECK:     return
// CHECK:   }
// CHECK: }

