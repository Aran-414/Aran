
// CHECK-LABEL: Testing : "simple_loop"
// CHECK-NEXT: Blocks : ^[[BB0:.*]], ^[[BB1:.*]], ^[[BB2:.*]], ^[[BB3:.*]]
// CHECK: Loop at depth 1 containing:
// CHECK-SAME: ^[[BB1]]<header><exiting>
// CHECK-SAME: ^[[BB2]]<latch>
func.func @simple_loop(%c: i1) {
  cf.br ^bb1
^bb1:
  cf.cond_br %c, ^bb2, ^bb3
^bb2:
  cf.br ^bb1
^bb3:
  return
}

