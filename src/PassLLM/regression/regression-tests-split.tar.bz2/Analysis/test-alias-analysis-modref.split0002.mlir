
// CHECK-LABEL: Testing : "mayalias"
// CHECK-DAG: store -> func.region0#0: Mod
// CHECK-DAG: load -> func.region0#0: Ref

// CHECK-DAG: store -> func.region0#1: Mod
// CHECK-DAG: load -> func.region0#1: Ref
func.func @mayalias(%arg0: memref<i32>, %arg1: memref<i32>, %value: i32) attributes {test.ptr = "func"} {
  memref.store %value, %arg1[] {test.ptr = "store"} : memref<i32>
  %1 = memref.load %arg1[] {test.ptr = "load"} : memref<i32>
  return {test.ptr = "return"}
}

