
// CHECK-LABEL: Testing : func_loop
func.func @func_loop(%arg0 : i32, %arg1 : i32) -> i32 {
  // CHECK: Block: 0
  // CHECK-NEXT: LiveIn:{{ *$}}
  // CHECK-NEXT: LiveOut: arg1@0
  // CHECK: BeginCurrentlyLive
  // CHECK: arith.constant
  // CHECK-SAME:  arg0@0 arg1@0 val_2
  // CHECK: cf.br
  // CHECK-SAME:  arg0@0 arg1@0 val_2
  // CHECK-NEXT: EndCurrentlyLive
  %const0 = arith.constant 0 : i32
  cf.br ^loopHeader(%const0, %arg0 : i32, i32)
^loopHeader(%counter : i32, %i : i32):
  // CHECK: Block: 1
  // CHECK-NEXT: LiveIn: arg1@0
  // CHECK-NEXT: LiveOut: arg1@0 arg0@1
  // CHECK-NEXT: BeginLivenessIntervals
  // CHECK-NEXT: val_5
  // CHECK-NEXT:     %2 = arith.cmpi
  // CHECK-NEXT:     cf.cond_br
  // CHECK-NEXT: EndLivenessIntervals
  // CHECK-NEXT: BeginCurrentlyLive
  // CHECK: arith.cmpi
  // CHECK-SAME:  arg1@0 arg0@1 arg1@1 val_5
  // CHECK: cf.cond_br
  // CHECK-SAME:  arg1@0 arg0@1 arg1@1 val_5
  // CHECK-NEXT: EndCurrentlyLive
  %lessThan = arith.cmpi slt, %counter, %arg1 : i32
  cf.cond_br %lessThan, ^loopBody(%i : i32), ^exit(%i : i32)
^loopBody(%val : i32):
  // CHECK: Block: 2
  // CHECK-NEXT: LiveIn: arg1@0 arg0@1
  // CHECK-NEXT: LiveOut: arg1@0
  // CHECK-NEXT: BeginLivenessIntervals
  // CHECK-NEXT: val_7
  // CHECK-NEXT:     %c
  // CHECK-NEXT:     %4 = arith.addi
  // CHECK-NEXT:     %5 = arith.addi
  // CHECK-NEXT: val_8
  // CHECK-NEXT:     %4 = arith.addi
  // CHECK-NEXT:     %5 = arith.addi
  // CHECK-NEXT:     cf.br
  // CHECK: EndLivenessIntervals
  // CHECK-NEXT: BeginCurrentlyLive
  // CHECK: arith.constant
  // CHECK-SAME:  arg1@0 arg0@1 arg0@2 val_7
  // CHECK: arith.addi
  // CHECK-SAME:  arg1@0 arg0@1 arg0@2 val_7 val_8
  // CHECK: arith.addi
  // CHECK-SAME:  arg1@0 arg0@1 val_7 val_8 val_9
  // CHECK: cf.br
  // CHECK-SAME:  arg1@0 val_8 val_9
  // CHECK-NEXT: EndCurrentlyLive
  %const1 = arith.constant 1 : i32
  %inc = arith.addi %val, %const1 : i32
  %inc2 = arith.addi %counter, %const1 : i32
  cf.br ^loopHeader(%inc, %inc2 : i32, i32)
^exit(%sum : i32):
  // CHECK: Block: 3
  // CHECK-NEXT: LiveIn: arg1@0
  // CHECK-NEXT: LiveOut:{{ *$}}
  // CHECK: BeginCurrentlyLive
  // CHECK: arith.addi
  // CHECK-SAME:  arg1@0 arg0@3 val_11
  // CHECK: return
  // CHECK-SAME:  val_11
  // CHECK-NEXT: EndCurrentlyLive
  %result = arith.addi %sum, %arg1 : i32
  return %result : i32
}

