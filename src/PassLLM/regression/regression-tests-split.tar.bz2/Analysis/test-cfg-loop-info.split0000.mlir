// RUN: mlir-opt -pass-pipeline="builtin.module(any(test-cfg-loop-info))" --split-input-file %s 2>&1 | FileCheck %s

// CHECK-LABEL: Testing : "no_loop_single_block"
// CHECK: no loops
func.func @no_loop_single_block() {
  return
}

