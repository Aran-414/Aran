
// CHECK-LABEL: Testing : nested_region2
func.func @nested_region2(%arg0 : index, %arg1 : index, %arg2 : index) {
  scf.for %arg3 = %arg0 to %arg1 step %arg2 {
    scf.for %arg4 = %arg0 to %arg1 step %arg2 {
      scf.for %arg5 = %arg0 to %arg1 step %arg2 { }
    }
  }
  return
}

// CHECK: --- DominanceInfo ---
// CHECK: Nearest(0, 0) = 0
// CHECK: Nearest(0, 1) = 1
// CHECK: Nearest(0, 2) = 2
// CHECK: Nearest(0, 3) = 3
// CHECK: Nearest(0, 4) = 4
// CHECK: Nearest(1, 0) = 1
// CHECK: Nearest(1, 1) = 1
// CHECK: Nearest(1, 2) = 2
// CHECK: Nearest(1, 3) = 3
// CHECK: Nearest(1, 4) = 4
// CHECK: Nearest(2, 0) = 2
// CHECK: Nearest(2, 1) = 2
// CHECK: Nearest(2, 2) = 2
// CHECK: Nearest(2, 3) = 3
// CHECK: Nearest(2, 4) = 4
// CHECK: Nearest(3, 0) = 3
// CHECK: Nearest(3, 1) = 3
// CHECK: Nearest(3, 2) = 3
// CHECK: Nearest(3, 3) = 3
// CHECK: Nearest(3, 4) = 4
// CHECK: Nearest(4, 0) = 4
// CHECK: Nearest(4, 1) = 4
// CHECK: Nearest(4, 2) = 4
// CHECK: Nearest(4, 3) = 4
// CHECK: Nearest(4, 4) = 4

// CHECK: --- PostDominanceInfo ---
// CHECK: Nearest(0, 0) = 0
// CHECK: Nearest(0, 1) = 1
// CHECK: Nearest(0, 2) = 2
// CHECK: Nearest(0, 3) = 3
// CHECK: Nearest(0, 4) = 4
// CHECK: Nearest(1, 0) = 1
// CHECK: Nearest(1, 1) = 1
// CHECK: Nearest(1, 2) = 2
// CHECK: Nearest(1, 3) = 3
// CHECK: Nearest(1, 4) = 4
// CHECK: Nearest(2, 0) = 2
// CHECK: Nearest(2, 1) = 2
// CHECK: Nearest(2, 2) = 2
// CHECK: Nearest(2, 3) = 3
// CHECK: Nearest(2, 4) = 4
// CHECK: Nearest(3, 0) = 3
// CHECK: Nearest(3, 1) = 3
// CHECK: Nearest(3, 2) = 3
// CHECK: Nearest(3, 3) = 3
// CHECK: Nearest(3, 4) = 4
// CHECK: Nearest(4, 0) = 4
// CHECK: Nearest(4, 1) = 4
// CHECK: Nearest(4, 2) = 4
// CHECK: Nearest(4, 3) = 4
// CHECK: Nearest(4, 4) = 4

// CHECK: --- Block Dominance relationship ---
// CHECK: dominates(0, 0) = 1 (properly = 0)
// CHECK: dominates(0, 1) = 0 (properly = 0)
// CHECK: dominates(0, 2) = 0 (properly = 0)
// CHECK: dominates(0, 3) = 0 (properly = 0)
// CHECK: dominates(0, 4) = 0 (properly = 0)
// CHECK: dominates(1, 0) = 1 (properly = 1)
// CHECK: dominates(1, 1) = 1 (properly = 0)
// CHECK: dominates(1, 2) = 0 (properly = 0)
// CHECK: dominates(1, 3) = 0 (properly = 0)
// CHECK: dominates(1, 4) = 0 (properly = 0)
// CHECK: dominates(2, 0) = 1 (properly = 1)
// CHECK: dominates(2, 1) = 1 (properly = 1)
// CHECK: dominates(2, 2) = 1 (properly = 0)
// CHECK: dominates(2, 3) = 0 (properly = 0)
// CHECK: dominates(2, 4) = 0 (properly = 0)
// CHECK: dominates(3, 0) = 1 (properly = 1)
// CHECK: dominates(3, 1) = 1 (properly = 1)
// CHECK: dominates(3, 2) = 1 (properly = 1)
// CHECK: dominates(3, 3) = 1 (properly = 0)
// CHECK: dominates(3, 4) = 0 (properly = 0)
// CHECK: dominates(4, 0) = 1 (properly = 1)
// CHECK: dominates(4, 1) = 1 (properly = 1)
// CHECK: dominates(4, 2) = 1 (properly = 1)
// CHECK: dominates(4, 3) = 1 (properly = 1)
// CHECK: dominates(4, 4) = 1 (properly = 1)

// CHECK: --- Block PostDominance relationship ---
// CHECK: postdominates(0, 0) = 1 (properly = 0)
// CHECK: postdominates(0, 1) = 0 (properly = 0)
// CHECK: postdominates(0, 2) = 0 (properly = 0)
// CHECK: postdominates(0, 3) = 0 (properly = 0)
// CHECK: postdominates(0, 4) = 0 (properly = 0)
// CHECK: postdominates(1, 0) = 1 (properly = 1)
// CHECK: postdominates(1, 1) = 1 (properly = 0)
// CHECK: postdominates(1, 2) = 0 (properly = 0)
// CHECK: postdominates(1, 3) = 0 (properly = 0)
// CHECK: postdominates(1, 4) = 0 (properly = 0)
// CHECK: postdominates(2, 0) = 1 (properly = 1)
// CHECK: postdominates(2, 1) = 1 (properly = 1)
// CHECK: postdominates(2, 2) = 1 (properly = 0)
// CHECK: postdominates(2, 3) = 0 (properly = 0)
// CHECK: postdominates(2, 4) = 0 (properly = 0)
// CHECK: postdominates(3, 0) = 1 (properly = 1)
// CHECK: postdominates(3, 1) = 1 (properly = 1)
// CHECK: postdominates(3, 2) = 1 (properly = 1)
// CHECK: postdominates(3, 3) = 1 (properly = 0)
// CHECK: postdominates(3, 4) = 0 (properly = 0)
// CHECK: postdominates(4, 0) = 1 (properly = 1)
// CHECK: postdominates(4, 1) = 1 (properly = 1)
// CHECK: postdominates(4, 2) = 1 (properly = 1)
// CHECK: postdominates(4, 3) = 1 (properly = 1)
// CHECK: postdominates(4, 4) = 1 (properly = 1)

// CHECK: module attributes {test.block_ids = array<i64: 4>} {
// CHECK:   func.func @nested_region2({{.*}}) attributes {test.block_ids = array<i64: 3>} {
// CHECK:     scf.for {{.*}} {
// CHECK:       scf.for {{.*}} {
// CHECK:         scf.for {{.*}} {
// CHECK:         } {test.block_ids = array<i64: 0>}
// CHECK:       } {test.block_ids = array<i64: 1>}
// CHECK:     } {test.block_ids = array<i64: 2>}
// CHECK:     return
// CHECK:   }
// CHECK: }

