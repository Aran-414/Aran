
// CHECK-LABEL: Testing : "no_loop"
// CHECK: no loops
func.func @no_loop() {
  cf.br ^bb1
^bb1:
  return
}

