
func.func private @callee(%0 : f32) -> f32 {
  %1 = arith.mulf %0, %0 : f32
  func.return %1 : f32
}

// CHECK-LABEL: test_tag: sub
// IP:    result #0: [a]
// LOCAL: result #0: [callarg0]
// LC_AW: result #0: [func.call]
func.func @test_caller_below_callee(%m0: memref<f32>, %arg: f32) {
  %0 = arith.subf %arg, %arg {tag = "sub"} : f32
  %1 = func.call @callee(%0) : (f32) -> f32
  memref.store %1, %m0[] {tag_name = "a"} : memref<f32>
  return
}

