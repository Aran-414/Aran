
// CHECK-LABEL: @recursive_call_cf
func.func @recursive_call_cf(%arg0: memref<f32>, %cond: i1) {
  // IP:         name = "pre"
  // IP-SAME:    next_access = {{\[}}["pre", "post"]]
  // LOCAL:      name = "pre"
  // LOCAL-SAME: next_access = ["unknown"]
  // LC_AR:      name = "pre"
  // LC_AR-SAME: next_access = {{\[}}["call", "post"]]
  %0 = memref.load %arg0[] {name = "pre"} : memref<f32>
  cf.cond_br %cond, ^bb1, ^bb2
^bb1:
  call @recursive_call_cf(%arg0, %cond) {name = "call"} : (memref<f32>, i1) -> ()
  cf.br ^bb2
^bb2:
  %2 = memref.load %arg0[] {name = "post"} : memref<f32>
  return
}

