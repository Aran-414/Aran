
func.func private @private0(%0 : i32) -> i32 {
  %1 = arith.addi %0, %0 {tag = "in_private0"} : i32
  func.return %1 : i32
}

// Positive test: Type (3) "is used to compute a value of type (1) or (2)"
// zero, ten, and one are live because they are used to decide the number of
// times the `for` loop executes, which in turn decides the value stored in
// memory.
// in_private0 and x are also live because they decide the value stored in
// memory.
// Negative test:
// y is not live even though the non-forwarded branch operand and x are live.
// CHECK-LABEL: test_tag: in_private0:
// CHECK-NEXT:  operand #0: live
// CHECK-NEXT:  operand #1: live
// CHECK-NEXT:  result #0: live
// CHECK-LABEL: test_tag: zero:
// CHECK-NEXT:  result #0: live
// CHECK-LABEL: test_tag: ten:
// CHECK-NEXT:  result #0: live
// CHECK-LABEL: test_tag: one:
// CHECK-NEXT:  result #0: live
// CHECK-LABEL: test_tag: x:
// CHECK-NEXT:  result #0: live
// CHECK-LABEL: test_tag: y:
// CHECK-NEXT:  result #0: not live
// CHECK-LABEL: test_tag: for:
// CHECK-NEXT:  operand #0: live
// CHECK-NEXT:  operand #1: live
// CHECK-NEXT:  operand #2: live
// CHECK-NEXT:  operand #3: live
// CHECK-NEXT:  operand #4: not live
// CHECK-NEXT:  result #0: live
// CHECK-NEXT:  result #1: not live
// CHECK-NEXT:  region: #0:
// CHECK-NEXT:  argument: #0: live
// CHECK-NEXT:  argument: #1: not live
// CHECK-NEXT:  argument: #2: not live
func.func @test_7_type_3(%arg0: memref<i32>) {
  %c0 = arith.constant {tag = "zero"} 0 : index
  %c10 = arith.constant {tag = "ten"} 10 : index
  %c1 = arith.constant {tag = "one"} 1 : index
  %x = arith.constant {tag = "x"} 0 : i32
  %y = arith.constant {tag = "y"} 1 : i32
  %0:2 = scf.for %arg1 = %c0 to %c10 step %c1 iter_args(%arg2 = %x, %arg3 = %y) -> (i32, i32) {
    %1 = arith.addi %x, %x : i32
    %2 = func.call @private0(%1) : (i32) -> i32
    scf.yield %2, %arg3 : i32, i32
  } {tag = "for"}
  memref.store %0#0, %arg0[] : memref<i32>
  return
}

