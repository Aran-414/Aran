
// CHECK-LABEL: @infinite_recursive_call
func.func @infinite_recursive_call(%arg0: memref<f32>) {
  // IP:         name = "pre"
  // IP-SAME:    next_access = {{\[}}["pre"]]
  // LOCAL:      name = "pre"
  // LOCAL-SAME: next_access = ["unknown"]
  // LC_AR:      name = "pre"
  // LC_AR-SAME: next_access = {{\[}}["call"]]
  memref.load %arg0[] {name = "pre"} : memref<f32>
  func.call @infinite_recursive_call(%arg0) {name = "call"} : (memref<f32>) -> ()
  memref.load %arg0[] {name = "post"} : memref<f32>
  return
}

