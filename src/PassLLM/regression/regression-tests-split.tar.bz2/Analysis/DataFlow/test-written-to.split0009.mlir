
// CHECK-LABEL: test_tag: zero
// CHECK: result #0: []
// CHECK-LABEL: test_tag: one
// CHECK: result #0: [a]
// CHECK-LABEL: test_tag: condition
// CHECK: operand #0: [brancharg0]
//
// The important thing to note in this test is that the sparse backward dataflow
// analysis framework also works on complex region branch ops like this one
// where the number of operands in the `scf.yield` op don't match the number of
// results in the parent op.
func.func @test_complex_while(%m0: memref<i32>, %cond: i1) {
  %zero = arith.constant {tag = "zero"} 0 : i32
  %one = arith.constant {tag = "one"} 1 : i32
  %0 = scf.while (%arg1 = %zero, %arg2 = %one) : (i32, i32) -> (i32) {
    scf.condition(%cond) {tag = "condition"} %arg2 : i32
  } do {
   ^bb0(%arg1: i32):
    scf.yield %arg1, %arg1: i32, i32
  }
  memref.store %0, %m0[] {tag_name = "a"} : memref<i32>
  return
}

