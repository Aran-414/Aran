
func.func private @callee(%arg0 : i32, %arg1 : i32) -> i32 {
  func.return %arg0 : i32
}

// CHECK-LABEL: test_tag: a

// IP:           operand #0: [b]
// LOCAL:        operand #0: [callarg0]
// LC_AW:        operand #0: [test.call_on_device]

// IP:           operand #1: []
// LOCAL:        operand #1: [callarg1]
// LC_AW:        operand #1: [test.call_on_device]

// IP:           operand #2: [callarg2]
// LOCAL:        operand #2: [callarg2]
// LC_AW:        operand #2: [test.call_on_device]

// CHECK:        result #0: [b]
func.func @test_call_on_device(%arg0: i32, %arg1: i32, %device: i32, %m0: memref<i32>) {
  %0 = test.call_on_device @callee(%arg0, %arg1), %device {tag = "a"} : (i32, i32, i32) -> (i32)
  memref.store %0, %m0[] {tag_name = "b"} : memref<i32>
  return
}

