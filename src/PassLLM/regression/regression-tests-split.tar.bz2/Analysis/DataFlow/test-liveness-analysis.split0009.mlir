
func.func private @private1(%0 : i32) -> i32 {
  %1 = func.call @private2(%0) : (i32) -> i32
  %2 = arith.muli %0, %1 {tag = "in_private1"} : i32
  func.return %2 : i32
}

func.func private @private2(%0 : i32) -> i32 {
  %cond = arith.index_cast %0 {tag = "in_private2"} : i32 to index
  %1 = scf.index_switch %cond -> i32
  case 1 {
    %ten = arith.constant 10 : i32
    scf.yield %ten : i32
  }
  case 2 {
    %twenty = arith.constant 20 : i32
    scf.yield %twenty : i32
  }
  default {
    %thirty = arith.constant 30 : i32
    scf.yield %thirty : i32
  }
  func.return %1 : i32
}

// Positive test: Type (3) "is used to compute a value of type (1) or (2)"
// in_private1, in_private2, and final are live because they are used to compute
// the value returned by this public function.
// CHECK-LABEL: test_tag: in_private1:
// CHECK-NEXT:  operand #0: live
// CHECK-NEXT:  operand #1: live
// CHECK-NEXT:  result #0: live
// CHECK-LABEL: test_tag: in_private2:
// CHECK-NEXT:  operand #0: live
// CHECK-NEXT:  result #0: live
// CHECK-LABEL: test_tag: final:
// CHECK-NEXT:  operand #0: live
// CHECK-NEXT:  operand #1: live
// CHECK-NEXT:  result #0: live
func.func @test_8_type_3(%arg: i32) -> (i32) {
  %0 = func.call @private1(%arg) : (i32) -> i32
  %final = arith.muli %0, %arg {tag = "final"} : i32
  return %final : i32
}

