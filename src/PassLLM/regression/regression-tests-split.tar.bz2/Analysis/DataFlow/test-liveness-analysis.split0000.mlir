// RUN: mlir-opt -split-input-file -test-liveness-analysis %s 2>&1 | FileCheck %s

// Positive test: Type (1.a) "is an operand of an op with memory effects"
// zero is live because it is stored in memory.
// CHECK-LABEL: test_tag: zero:
// CHECK-NEXT:  result #0: live
func.func @test_1_type_1.a(%arg0: memref<i32>) {
  %c0_i32 = arith.constant {tag = "zero"} 0 : i32
  memref.store %c0_i32, %arg0[] : memref<i32>
  return
}

