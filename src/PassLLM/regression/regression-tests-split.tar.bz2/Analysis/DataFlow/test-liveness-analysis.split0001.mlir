
// Positive test: Type (1.b) "is a non-forwarded branch operand and a block
// where its op could take the control has an op with memory effects"
// %arg2 is live because it can make the control go into a block with a memory
// effecting op.
// CHECK-LABEL: test_tag: br:
// CHECK-NEXT:  operand #0: live
// CHECK-NEXT:  operand #1: live
// CHECK-NEXT:  operand #2: live
func.func @test_2_RegionBranchOpInterface_type_1.b(%arg0: memref<i32>, %arg1: memref<i32>, %arg2: i1) {
  %c0_i32 = arith.constant 0 : i32
  cf.cond_br %arg2, ^bb1(%c0_i32 : i32), ^bb2(%c0_i32 : i32) {tag = "br"}
^bb1(%0 : i32):
  memref.store %0, %arg0[] : memref<i32>
  cf.br ^bb3
^bb2(%1 : i32):
  memref.store %1, %arg1[] : memref<i32>
  cf.br ^bb3
^bb3:
  return
}

