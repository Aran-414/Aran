
// Positive test: Type(1.c) "is a non-forwarded branch operand and its branch
// op could result in different result"
// CHECK-LABEL: test_tag: cond_br:
// CHECK-NEXT:  operand #0: live
// CHECK-NEXT:  operand #1: live
// CHECK-NEXT:  operand #2: live
func.func @test_branch_result_in_different_result_1.c(%arg0 : tensor<f32>, %arg1 : tensor<f32>, %arg2 : i1) -> tensor<f32> {
  cf.cond_br %arg2, ^bb1(%arg0 : tensor<f32>), ^bb2(%arg1 : tensor<f32>) {tag = "cond_br"}
^bb1(%0 : tensor<f32>):
  cf.br ^bb3(%0 : tensor<f32>)
^bb2(%1 : tensor<f32>):
  cf.br ^bb3(%1 : tensor<f32>)
^bb3(%2 : tensor<f32>):
  return %2 : tensor<f32>
}

