
// CHECK-LABEL: test_tag: c0
// CHECK: result #0: [b]
// CHECK-LABEL: test_tag: c1
// CHECK: result #0: [b]
// CHECK-LABEL: test_tag: condition
// CHECK: result #0: [brancharg0]
// CHECK-LABEL: test_tag: c2
// CHECK: result #0: [a]
// CHECK-LABEL: test_tag: c3
// CHECK: result #0: [a]
func.func @test_if(%m0: memref<i32>, %m1: memref<i32>, %condition: i1) {
  %c0 = arith.constant {tag = "c0"} 2 : i32
  %c1 = arith.constant {tag = "c1"} 3 : i32
  %condition2 = arith.addi %condition, %condition {tag = "condition"} : i1
  %0, %1 = scf.if %condition2 -> (i32, i32) {
    %c2 = arith.constant {tag = "c2"} 0 : i32
    scf.yield %c2, %c0: i32, i32
  } else {
    %c3 = arith.constant {tag = "c3"} 1 : i32
    scf.yield %c3, %c1: i32, i32
  }
  memref.store %0, %m0[] {tag_name = "a"} : memref<i32>
  memref.store %1, %m1[] {tag_name = "b"} : memref<i32>
  return
}

