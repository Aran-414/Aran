
// Negative test: None of the types (1), (2), or (3)
// zero is not live because it has no effect outside the program: it doesn't
// affect the memory or the program output.
// CHECK-LABEL: test_tag: zero:
// CHECK-NEXT:  result #0: not live
// CHECK-LABEL: test_tag: one:
// CHECK-NEXT:  result #0: live
func.func @test_9_negative() -> (f32){
  %0 = arith.constant {tag = "zero"} 0.0 : f32
  %1 = arith.constant {tag = "one"} 1.0 : f32
  return %1 : f32
}

