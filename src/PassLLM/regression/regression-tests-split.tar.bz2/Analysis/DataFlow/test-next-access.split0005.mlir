
func.func private @callee1(%arg0: memref<f32>) {
  // IP:         name = "callee1"
  // IP-SAME:    next_access = {{\[}}["post"]]
  // LOCAL:      name = "callee1"
  // LOCAL-SAME: next_access = ["unknown"]
  memref.load %arg0[] {name = "callee1"} : memref<f32>
  return
}

func.func private @callee2(%arg0: memref<f32>) {
  // IP:         name = "callee2"
  // IP-SAME:    next_access = {{\[}}["post"]]
  // LOCAL:      name = "callee2"
  // LOCAL-SAME: next_access = ["unknown"]
  memref.load %arg0[] {name = "callee2"} : memref<f32>
  return
}

func.func @conditonal_call(%arg0: memref<f32>, %cond: i1) {
  // IP:         name = "pre"
  // IP-SAME:    next_access = {{\[}}["callee1", "callee2"]]
  // LOCAL:      name = "pre"
  // LOCAL-SAME: next_access = ["unknown"]
  // LC_AR:      name = "pre"
  // LC_AR-SAME: next_access = {{\[}}["call1", "call2"]]
  memref.load %arg0[] {name = "pre"} : memref<f32>
  scf.if %cond {
    func.call @callee1(%arg0) {name = "call1"} : (memref<f32>) -> ()
  } else {
    func.call @callee2(%arg0) {name = "call2"} : (memref<f32>) -> ()
  }
  memref.load %arg0[] {name = "post"} : memref<f32>
  return
}

