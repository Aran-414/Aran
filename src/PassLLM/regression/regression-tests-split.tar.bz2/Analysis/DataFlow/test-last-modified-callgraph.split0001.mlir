
// CHECK-LABEL: test_tag: after_call
// IP:    operand #0
// IP-NEXT:    - write0
// LOCAL: operand #0
// LOCAL-NEXT: - <unknown>
// LC_AW: operand #0
// LC_AW-NEXT: - func.call
func.func private @void_return(%ptr: memref<i32>) {
  return
}

func.func @test_call_void_return() {
  %ptr = memref.alloc() : memref<i32>
  %c0 = arith.constant 0 : i32
  memref.store %c0, %ptr[] {tag_name = "write0"} : memref<i32>
  func.call @void_return(%ptr) : (memref<i32>) -> ()
  memref.load %ptr[] {tag = "after_call"} : memref<i32>
  return
}

