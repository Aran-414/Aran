
// CHECK-LABEL: @recursive_call
func.func @recursive_call(%arg0: memref<f32>, %cond: i1) {
  // IP:         name = "pre"
  // IP-SAME:    next_access = {{\[}}["post", "pre"]]
  // LOCAL:      name = "pre"
  // LOCAL-SAME: next_access = ["unknown"]
  // LC_AR:      name = "pre"
  // LC_AR-SAME: next_access = {{\[}}["post", "call"]]
  memref.load %arg0[] {name = "pre"} : memref<f32>
  scf.if %cond {
    func.call @recursive_call(%arg0, %cond) {name = "call"} : (memref<f32>, i1) -> ()
  }
  memref.load %arg0[] {name = "post"} : memref<f32>
  return
}

