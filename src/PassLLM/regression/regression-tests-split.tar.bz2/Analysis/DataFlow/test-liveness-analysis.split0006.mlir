
// Positive test: Type (2) "is returned by a public function"
// zero is live because it is returned by a public function.
// CHECK-LABEL: test_tag: zero:
// CHECK-NEXT:  result #0: live
func.func @test_5_type_2() -> (f32){
  %0 = arith.constant {tag = "zero"} 0.0 : f32
  return %0 : f32
}

