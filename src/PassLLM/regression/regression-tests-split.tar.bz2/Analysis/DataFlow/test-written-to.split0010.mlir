
// CHECK-LABEL: test_tag: zero
// CHECK: result #0: [brancharg0]
// CHECK-LABEL: test_tag: ten
// CHECK: result #0: [brancharg1]
// CHECK-LABEL: test_tag: one
// CHECK: result #0: [brancharg2]
// CHECK-LABEL: test_tag: x
// CHECK: result #0: [a]
func.func @test_for(%m0: memref<i32>) {
  %zero = arith.constant {tag = "zero"} 0 : index
  %ten = arith.constant {tag = "ten"} 10 : index
  %one = arith.constant {tag = "one"} 1 : index
  %x = arith.constant {tag = "x"} 0 : i32
  %0 = scf.for %i = %zero to %ten step %one iter_args(%ix = %x) -> (i32) {
    scf.yield %ix : i32
  }
  memref.store %0, %m0[] {tag_name = "a"} : memref<i32>
  return
}

