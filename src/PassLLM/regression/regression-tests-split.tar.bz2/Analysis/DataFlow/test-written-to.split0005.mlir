
// CHECK-LABEL: test_tag: add
// IP:    result #0: [a]
// LOCAL: result #0: [callarg0]
// LC_AW: result #0: [func.call]
func.func @test_caller(%m0: memref<f32>, %arg: f32) {
  %0 = arith.addf %arg, %arg {tag = "add"} : f32
  %1 = func.call @callee(%0) : (f32) -> f32
  %2 = arith.mulf %1, %1 : f32
  %3 = arith.mulf %2, %2 : f32
  %4 = arith.mulf %3, %3 : f32
  memref.store %4, %m0[] {tag_name = "a"} : memref<f32>
  return
}

func.func private @callee(%0 : f32) -> f32 {
  %1 = arith.mulf %0, %0 : f32
  %2 = arith.mulf %1, %1 : f32
  func.return %2 : f32
}

