

// In this test, the "call" operation also accesses %arg0 itself before
// transferring control flow to the callee. Therefore, the order of accesses is
// "caller" -> "call" -> "callee" -> "post"

func.func private @callee(%arg0: memref<f32>) {
  // IP:         name = "callee"
  // IP-SAME:    next_access = {{\[}}["post"]]
  // LOCAL:      name = "callee"
  // LOCAL-SAME: next_access = ["unknown"]
  memref.load %arg0[] {name = "callee"} : memref<f32>
  return
}

// CHECK-LABEL: @call_and_store_before
func.func @call_and_store_before(%arg0: memref<f32>) {
  // IP:         name = "caller"
  // IP-SAME:    next_access = {{\[}}["call"]]
  // LOCAL:      name = "caller"
  // LOCAL-SAME: next_access = ["unknown"]
  // LC_AR:      name = "caller"
  // LC_AR-SAME: next_access = {{\[}}["call"]]
  memref.load %arg0[] {name = "caller"} : memref<f32>
  // Note that the access after the entire call is "post".
  // CHECK:      name = "call"
  // CHECK-SAME: next_access = {{\[}}["post"], ["post"]]
  test.call_and_store @callee(%arg0), %arg0 {name = "call", store_before_call = true} : (memref<f32>, memref<f32>) -> ()
  // CHECK:      name = "post"
  // CHECK-SAME: next_access = ["unknown"]
  memref.load %arg0[] {name = "post"} : memref<f32>
  return
}

