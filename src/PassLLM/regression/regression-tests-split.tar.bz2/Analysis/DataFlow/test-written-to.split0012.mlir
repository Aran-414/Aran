
// The point of this test is to ensure the analysis doesn't crash in presence of
// external functions.

// CHECK-LABEL: llvm.func @decl(i64)
// CHECK-LABEL: llvm.func @func(%arg0: i64) {
// CHECK-NEXT:  llvm.call @decl(%arg0) : (i64) -> ()
// CHECK-NEXT:  llvm.return

llvm.func @decl(i64)

llvm.func @func(%lb : i64) -> () {
  llvm.call @decl(%lb) : (i64) -> ()
  llvm.return
}

