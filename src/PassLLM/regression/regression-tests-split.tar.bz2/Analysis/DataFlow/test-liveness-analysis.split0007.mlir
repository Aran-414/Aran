
// Positive test: Type (3) "is used to compute a value of type (1) or (2)"
// %arg1 is live because the scf.while has a live result and %arg1 is a
// non-forwarded branch operand.
// %arg2 is live because it is forwarded to the live result of the scf.while
// op.
// %arg5 is live because it is forwarded to %arg8 which is live.
// %arg8 is live because it is forwarded to %arg4 which is live as it writes
// to memory.
// Negative test:
// %arg3 is not live even though %arg1, %arg2, and %arg5 are live because it
// is neither a non-forwarded branch operand nor a forwarded operand that
// forwards to a live value. It actually is a forwarded operand that forwards
// to non-live values %0#1 and %arg7.
// CHECK-LABEL: test_tag: condition:
// CHECK-NEXT:  operand #0: live
// CHECK-NEXT:  operand #1: live
// CHECK-NEXT:  operand #2: not live
// CHECK-NEXT:  operand #3: live
// CHECK-LABEL: test_tag: add:
// CHECK-NEXT:  operand #0: live
func.func @test_6_RegionBranchTerminatorOpInterface_type_3(%arg0: memref<i32>, %arg1: i1) -> (i32) {
  %c0_i32 = arith.constant 0 : i32
  %c1_i32 = arith.constant 1 : i32
  %c2_i32 = arith.constant 2 : i32
  %0:3 = scf.while (%arg2 = %c0_i32, %arg3 = %c1_i32, %arg4 = %c2_i32, %arg5 = %c2_i32) : (i32, i32, i32, i32) -> (i32, i32, i32) {
    memref.store %arg4, %arg0[] : memref<i32>
    scf.condition(%arg1) {tag = "condition"} %arg2, %arg3, %arg5 : i32, i32, i32
  } do {
  ^bb0(%arg6: i32, %arg7: i32, %arg8: i32):
    %1 = arith.addi %arg8, %arg8 {tag = "add"} : i32
    %c3_i32 = arith.constant 3 : i32
    scf.yield %arg6, %arg7, %arg8, %c3_i32 : i32, i32, i32, i32
  }
  return %0#0 : i32
}

