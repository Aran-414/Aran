
// CHECK-LABEL: test_tag: default_a
// CHECK:       result #0: [a]
// CHECK-LABEL: test_tag: default_b
// CHECK:       result #0: [b]
// CHECK-LABEL: test_tag: 1a
// CHECK:       result #0: [a]
// CHECK-LABEL: test_tag: 1b
// CHECK:       result #0: [b]
// CHECK-LABEL: test_tag: 2a
// CHECK:       result #0: [a]
// CHECK-LABEL: test_tag: 2b
// CHECK:       result #0: [b]
// CHECK-LABEL: test_tag: switch
// CHECK:       operand #0: [brancharg0]
func.func @test_switch(%arg0 : index, %m0: memref<i32>) {
  %0, %1 = scf.index_switch %arg0 {tag="switch"} -> i32, i32
  case 1 {
    %2 = arith.constant {tag="1a"} 10 : i32
    %3 = arith.constant {tag="1b"} 100 : i32
    scf.yield %2, %3 : i32, i32
  }
  case 2 {
    %4 = arith.constant {tag="2a"} 20 : i32
    %5 = arith.constant {tag="2b"} 200 : i32
    scf.yield %4, %5 : i32, i32
  }
  default {
    %6 = arith.constant {tag="default_a"} 30 : i32
    %7 = arith.constant {tag="default_b"} 300 : i32
    scf.yield %6, %7 : i32, i32
  }
  memref.store %0, %m0[] {tag_name = "a"} : memref<i32>
  memref.store %1, %m0[] {tag_name = "b"} : memref<i32>
  return
}

