
func.func private @void_return(%ptr: memref<i32>)

// CHECK-LABEL: test_tag: after_opaque_call:
// CHECK:        operand #0
// IP_ONLY:       - <unknown>
// IP_AW:         - func.call
func.func @test_opaque_call_return() {
  %ptr = memref.alloc() : memref<i32>
  %c0 = arith.constant 0 : i32
  memref.store %c0, %ptr[] {tag_name = "write0"} : memref<i32>
  func.call @void_return(%ptr) : (memref<i32>) -> ()
  memref.load %ptr[] {tag = "after_opaque_call"} : memref<i32>
  return
}
