
// Positive test: Type (1.b) "is a non-forwarded branch operand and a block
// where its op could take the control has an op with memory effects"
// %arg0 is live because it can make the control go into a block with a memory
// effecting op.
// CHECK-LABEL: test_tag: flag:
// CHECK-NEXT:  operand #0: live
func.func @test_3_BranchOpInterface_type_1.b(%arg0: i32, %arg1: memref<i32>, %arg2: memref<i32>) {
  %c0_i32 = arith.constant 0 : i32
  cf.switch %arg0 : i32, [
    default: ^bb1,
    42: ^bb2
  ] {tag = "flag"}
^bb1:
  memref.store %c0_i32, %arg1[] : memref<i32>
  cf.br ^bb3
^bb2:
  memref.store %c0_i32, %arg2[] : memref<i32>
  cf.br ^bb3
^bb3:
  return
}

