
// CHECK-LABEL: test_tag: zero
// CHECK: result #0: [c]
// CHECK-LABEL: test_tag: init
// CHECK: result #0: [a b c]
// CHECK-LABEL: test_tag: condition
// CHECK: operand #0: [brancharg0]
// CHECK: operand #2: [a b c]
func.func @test_while(%m0: memref<i32>, %init : i32, %cond: i1) {
  %zero = arith.constant {tag = "zero"} 0 : i32
  %init2 = arith.addi %init, %init {tag = "init"} : i32
  %0, %1 = scf.while (%arg1 = %zero, %arg2 = %init2) : (i32, i32) -> (i32, i32) {
    memref.store %arg2, %m0[] {tag_name = "a"} : memref<i32>
    scf.condition(%cond) {tag = "condition"} %arg1, %arg2 : i32, i32
  } do {
   ^bb0(%arg1: i32, %arg2: i32):
    memref.store %arg1, %m0[] {tag_name = "c"} : memref<i32>
    %res = arith.addi %arg2, %arg2 : i32
    scf.yield %res, %res: i32, i32
  }
  memref.store %1, %m0[] {tag_name = "b"} : memref<i32>
  return
}

