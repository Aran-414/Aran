
func.func private @private(%arg0 : i32, %arg1 : i32) {
  func.return
}

// Positive test: Type (1.d) "is a non-forwarded call operand"
// CHECK-LABEL: test_tag: call
// CHECK-LABEL:  operand #0: not live
// CHECK-LABEL:  operand #1: not live
// CHECK-LABEL:  operand #2: live
func.func @test_4_type_1.d(%arg0: i32, %arg1: i32, %device: i32, %m0: memref<i32>) {
  test.call_on_device @private(%arg0, %arg1), %device {tag = "call"} : (i32, i32, i32) -> ()
  return
}

