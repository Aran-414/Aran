
// Negative test: None of the types (1), (2), or (3)
// %1 is not live because it has no effect outside the program: it doesn't
// affect the memory or the program output. Even though it is returned by the
// function `@private_1`, it is never used by the caller.
// Note that this test clearly shows how this liveness analysis utility differs
// from the existing liveness utility present at
// llvm-project/mlir/include/mlir/Analysis/Liveness.h. The latter marks %1 as
// live as it exists the block of function `@private_1`, simply because it is
// computed inside and returned by the block, irrespective of whether or not it
// is used by the caller.
// CHECK-LABEL: test_tag: one:
// CHECK:  result #0: not live
func.func private @private_1() -> (i32, i32) {
  %0 = arith.constant 0 : i32
  %1 = arith.addi %0, %0 {tag = "one"} : i32
  return %0, %1 : i32, i32
}
func.func @test_10_negative() -> (i32) {
  %0:2 = func.call @private_1() : () -> (i32, i32)
  return %0#0 : i32
}

