
// In this test, the "call" operation also accesses %arg0 itself after getting
// control flow back from the callee. Therefore, the order of accesses is
// "caller" -> "callee" -> "call" -> "post"

func.func private @callee(%arg0: memref<f32>) {
  // IP:         name = "callee"
  // IP-SAME:    next_access = {{\[}}["call"]]
  // LOCAL:      name = "callee"
  // LOCAL-SAME: next_access = ["unknown"]
  memref.load %arg0[] {name = "callee"} : memref<f32>
  return
}

// CHECK-LABEL: @call_and_store_after
func.func @call_and_store_after(%arg0: memref<f32>) {
  // IP:         name = "caller"
  // IP-SAME:    next_access = {{\[}}["callee"]]
  // LOCAL:      name = "caller"
  // LOCAL-SAME: next_access = ["unknown"]
  // LC_AR:      name = "caller"
  // LC_AR-SAME: next_access = {{\[}}["call"]]
  memref.load %arg0[] {name = "caller"} : memref<f32>
  // CHECK:      name = "call"
  // CHECK-SAME: next_access = {{\[}}["post"], ["post"]]
  test.call_and_store @callee(%arg0), %arg0 {name = "call", store_before_call = false} : (memref<f32>, memref<f32>) -> ()
  // CHECK:      name = "post"
  // CHECK-SAME: next_access = ["unknown"]
  memref.load %arg0[] {name = "post"} : memref<f32>
  return
}

