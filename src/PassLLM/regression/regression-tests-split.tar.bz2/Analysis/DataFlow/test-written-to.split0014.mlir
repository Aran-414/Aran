
func.func private @external_callee(%arg0: i32) -> i32

// CHECK-LABEL: test_tag: add_external
// IP:    operand #0: [callarg0]
// LOCAL: operand #0: [callarg0]
// LC_AW: operand #0: [func.call]
// IP_AW: operand #0: [func.call]

func.func @test_external_callee(%arg0: i32, %m0: memref<i32>) {
  %0 = arith.addi %arg0, %arg0 { tag = "add_external"}: i32
  %1 = func.call @external_callee(%arg0) : (i32) -> i32
  memref.store %1, %m0[] {tag_name = "a"} : memref<i32>
  return
}
