
func.func private @callee1(%0 : f32) -> f32 {
  %1 = func.call @callee2(%0) : (f32) -> f32
  func.return %1 : f32
}

func.func private @callee2(%0 : f32) -> f32 {
  %1 = func.call @callee3(%0) : (f32) -> f32
  func.return %1 : f32
}

func.func private @callee3(%0 : f32) -> f32 {
  func.return %0 : f32
}

// CHECK-LABEL: test_tag: mul
// IP:    result #0: [a]
// LOCAL: result #0: [callarg0]
// LC_AW: result #0: [func.call]
func.func @test_callchain(%m0: memref<f32>, %arg: f32) {
  %0 = arith.mulf %arg, %arg {tag = "mul"} : f32
  %1 = func.call @callee1(%0) : (f32) -> f32
  memref.store %1, %m0[] {tag_name = "a"} : memref<f32>
  return
}

