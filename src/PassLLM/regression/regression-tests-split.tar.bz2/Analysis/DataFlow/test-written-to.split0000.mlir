// RUN: mlir-opt -split-input-file -test-written-to %s 2>&1 |\
// RUN:          FileCheck %s --check-prefixes=CHECK,IP
// RUN: mlir-opt -split-input-file -test-written-to='interprocedural=false' %s \
// RUN:          2>&1 | FileCheck %s --check-prefixes=CHECK,LOCAL
// RUN: mlir-opt -split-input-file \
// RUN:          -test-written-to='assume-func-writes=true' %s 2>&1 |\
// RUN:          FileCheck %s --check-prefixes=CHECK,IP_AW
// RUN: mlir-opt -split-input-file \
// RUN:       -test-written-to='interprocedural=false assume-func-writes=true' \
// RUN:       %s 2>&1 | FileCheck %s --check-prefixes=CHECK,LC_AW

// Check prefixes are as follows:
// 'check': common for all runs;
// 'ip': interprocedural runs;
// 'ip_aw': interpocedural runs assuming calls to external functions write to
//          all arguments;
// 'local': local (non-interprocedural) analysis not assuming calls writing;
// 'lc_aw': local analysis assuming external calls writing to all arguments.

// Note that despite the name of the test analysis being "written to", it is set
// up in a peculiar way where passing a value through a block or region argument
// (via visitCall/BranchOperand) is considered as "writing" that value to the
// corresponding operand, which is itself a value and not necessarily "memory".
// This is arguably okay for testing purposes, but may be surprising for readers
// trying to interpret this test using their intuition.

// CHECK-LABEL: test_tag: constant0
// CHECK: result #0: [a]
// CHECK-LABEL: test_tag: constant1
// CHECK: result #0: [b]
func.func @test_two_writes(%m0: memref<i32>, %m1: memref<i32>) -> (memref<i32>, memref<i32>) {
  %c0 = arith.constant {tag = "constant0"} 0 : i32
  %c1 = arith.constant {tag = "constant1"} 1 : i32
  memref.store %c0, %m0[] {tag_name = "a"} : memref<i32>
  memref.store %c1, %m1[] {tag_name = "b"} : memref<i32>
  return %m0, %m1 : memref<i32>, memref<i32>
}

