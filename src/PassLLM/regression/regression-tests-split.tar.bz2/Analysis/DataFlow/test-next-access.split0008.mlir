
// In this test, the "region" operation also accesses %arg0 itself before
// entering the region. Therefore:
//   - the next access of "pre" is the "region" operation itself;
//   - at the entry of the block, the next access is "post".
// CHECK-LABEL: @store_with_a_region
func.func @store_with_a_region_before(%arg0: memref<f32>) {
  // CHECK:      name = "pre"
  // CHECK-SAME: next_access = {{\[}}["region"]]
  memref.load %arg0[] {name = "pre"} : memref<f32>
  // CHECK:              name = "region"
  // CHECK-SAME: next_access = {{\[}}["post"]]
  // CHECK-SAME: next_at_entry_point = {{\[}}{{\[}}["post"]]]
  test.store_with_a_region %arg0 attributes { name = "region", store_before_region = true } {
    test.store_with_a_region_terminator
  } : memref<f32>
  memref.load %arg0[] {name = "post"} : memref<f32>
  return
}

// In this test, the "region" operation also accesses %arg0 itself after
// exiting from the region. Therefore:
//   - the next access of "pre" is the "region" operation itself;
//   - at the entry of the block, the next access is "region".
// CHECK-LABEL: @store_with_a_region
func.func @store_with_a_region_after(%arg0: memref<f32>) {
  // CHECK:      name = "pre"
  // CHECK-SAME: next_access = {{\[}}["region"]]
  memref.load %arg0[] {name = "pre"} : memref<f32>
  // CHECK:      name = "region"
  // CHECK-SAME: next_access = {{\[}}["post"]]
  // CHECK-SAME: next_at_entry_point = {{\[}}{{\[}}["region"]]]
  test.store_with_a_region %arg0 attributes { name = "region", store_before_region = false } {
    test.store_with_a_region_terminator
  } : memref<f32>
  memref.load %arg0[] {name = "post"} : memref<f32>
  return
}

// In this test, the operation with a region stores to %arg0 before going to the
// region. Therefore: 
//   - the next access of "pre" is the "region" operation itself;
//   - the next access of the "region" operation (computed as the next access
//     *after* said operation) is the "post" operation;
//   - the next access of the "inner" operation is also "post";
//   - the next access at the entry point of the region of the "region" operation
//     is the "inner" operation.
// That is, the order of access is: "pre" -> "region" -> "inner" -> "post".
// CHECK-LABEL: @store_with_a_region_before_containing_a_load
func.func @store_with_a_region_before_containing_a_load(%arg0: memref<f32>) {
  // CHECK:      name = "pre"
  // CHECK-SAME: next_access = {{\[}}["region"]]
  memref.load %arg0[] {name = "pre"} : memref<f32>
  // CHECK:      name = "region"
  // CHECK-SAME: next_access = {{\[}}["post"]]
  // CHECK-SAME: next_at_entry_point = {{\[}}{{\[}}["inner"]]]
  test.store_with_a_region %arg0 attributes { name = "region", store_before_region = true } {
    // CHECK:      name = "inner"
    // CHECK-SAME: next_access = {{\[}}["post"]]
    memref.load %arg0[] {name = "inner"} : memref<f32>
    test.store_with_a_region_terminator
  } : memref<f32>
  // CHECK:      name = "post"
  // CHECK-SAME: next_access = ["unknown"]
  memref.load %arg0[] {name = "post"} : memref<f32>
  return
}

// In this test, the operation with a region stores to %arg0 after exiting from
// the region. Therefore:
//   - the next access of "pre" is "inner";
//   - the next access of the "region" operation (computed as the next access
//     *after* said operation) is the "post" operation);
//   - the next access at the entry point of the region of the "region" operation
//     is the "inner" operation;
//   - the next access of the "inner" operation is the "region" operation itself.
// That is, the order of access is "pre" -> "inner" -> "region" -> "post".
// CHECK-LABEL: @store_with_a_region_after_containing_a_load
func.func @store_with_a_region_after_containing_a_load(%arg0: memref<f32>) {
  // CHECK:      name = "pre"
  // CHECK-SAME: next_access = {{\[}}["inner"]]
  memref.load %arg0[] {name = "pre"} : memref<f32>
  // CHECK:      name = "region"
  // CHECK-SAME: next_access = {{\[}}["post"]]
  // CHECK-SAME: next_at_entry_point = {{\[}}{{\[}}["inner"]]]
  test.store_with_a_region %arg0 attributes { name = "region", store_before_region = false } {
    // CHECK:      name = "inner"
    // CHECK-SAME: next_access = {{\[}}["region"]]
    memref.load %arg0[] {name = "inner"} : memref<f32>
    test.store_with_a_region_terminator
  } : memref<f32>
  // CHECK:      name = "post"
  // CHECK-SAME: next_access = ["unknown"]
  memref.load %arg0[] {name = "post"} : memref<f32>
  return
}

