
// CHECK-LABEL: test_tag: two
// CHECK: result #0: [a]
func.func @test_infinite_loop(%m0: memref<i32>) {
  %0 = arith.constant 0 : i32
  %1 = arith.constant 1 : i32
  %2 = arith.constant {tag = "two"} 2 : i32
  %3 = arith.constant -1 : i32
  cf.br ^loop(%0, %1, %2: i32, i32, i32)
^loop(%a: i32, %b: i32, %c: i32):
  memref.store %a, %m0[] {tag_name = "a"} : memref<i32>
  cf.br ^loop(%b, %c, %3 : i32, i32, i32)
}

