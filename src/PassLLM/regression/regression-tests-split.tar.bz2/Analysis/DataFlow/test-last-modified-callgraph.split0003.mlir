
func.func private @callee(%arg0: memref<f32>) -> memref<f32> {
  %2 = arith.constant 2.0 : f32
  memref.load %arg0[] {tag = "call_and_store_after::enter_callee"} : memref<f32>
  memref.store %2, %arg0[] {tag_name = "callee"} : memref<f32>
  memref.load %arg0[] {tag = "exit_callee"} : memref<f32>
  return %arg0 : memref<f32>
}

// In this test, the "call" operation also stores to %arg0 itself after getting
// control flow back from the callee. Therefore, the order of accesses is
// "pre" -> "callee" -> "call" -> "post"

// CHECK-LABEL: test_tag: call_and_store_after::enter_callee:
// IP:     operand #0
// IP:      - pre
// LOCAL:  operand #0
// LOCAL:   - <unknown>
// LC_AW:  operand #0
// LC_AW:   - <unknown>

// CHECK: test_tag: exit_callee:
// CHECK:  operand #0
// CHECK:   - callee

// CHECK: test_tag: before_call:
// CHECK:  operand #0
// CHECK:   - pre

// CHECK:    test_tag: after_call:
// IP:     operand #0
// IP:      - call
// LOCAL:  operand #0
// LOCAL:   - <unknown>
// LC_AW:  operand #0
// LC_AW:   - call

// CHECK: test_tag: return:
// CHECK:  operand #0
// CHECK:   - post
func.func @call_and_store_after(%arg0: memref<f32>) -> memref<f32> {
  %0 = arith.constant 0.0 : f32
  %1 = arith.constant 1.0 : f32
  memref.store %0, %arg0[] {tag_name = "pre"} : memref<f32>
  memref.load %arg0[] {tag = "before_call"} : memref<f32>
  test.call_and_store @callee(%arg0), %arg0 {tag_name = "call", store_before_call = false} : (memref<f32>, memref<f32>) -> ()
  memref.load %arg0[] {tag = "after_call"} : memref<f32>
  memref.store %1, %arg0[] {tag_name = "post"} : memref<f32>
  return {tag = "return"} %arg0 : memref<f32>
}

