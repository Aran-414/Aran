
// CHECK-LABEL: test_tag: c0
// CHECK: result #0: [a c]
// CHECK-LABEL: test_tag: c1
// CHECK: result #0: [b c]
// CHECK-LABEL: test_tag: br
// CHECK: operand #0: [brancharg0]
func.func @test_blocks(%m0: memref<i32>,
                       %m1: memref<i32>,
                       %m2: memref<i32>, %cond : i1) {
  %0 = arith.constant {tag = "c0"} 0 : i32
  %1 = arith.constant {tag = "c1"} 1 : i32
  cf.cond_br %cond, ^a(%0: i32), ^b(%1: i32) {tag = "br"}
^a(%a0: i32):
  memref.store %a0, %m0[] {tag_name = "a"} : memref<i32>
  cf.br ^c(%a0 : i32)
^b(%b0: i32):
  memref.store %b0, %m1[] {tag_name = "b"} : memref<i32>
  cf.br ^c(%b0 : i32)
^c(%c0 : i32):
  memref.store %c0, %m2[] {tag_name = "c"} : memref<i32>
  return
}

