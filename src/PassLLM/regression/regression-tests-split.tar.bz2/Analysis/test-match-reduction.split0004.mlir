
// expected-remark@below {{Testing function}}
func.func @affine_no_red_rec(%in: memref<512xf32>) {
 %cst = arith.constant 0.000000e+00 : f32
 // %rec is the value loaded in the previous iteration.
 // expected-remark@below {{Reduction NOT found in output #0!}}
 %final_val = affine.for %j = 0 to 512 iter_args(%rec = %cst) -> (f32) {
   %ld = affine.load %in[%j] : memref<512xf32>
   %add = arith.addf %ld, %rec : f32
   affine.yield %ld : f32
 }
 return
}

