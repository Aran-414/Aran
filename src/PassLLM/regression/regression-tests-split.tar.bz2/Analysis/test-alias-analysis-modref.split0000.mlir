// RUN: mlir-opt %s -pass-pipeline='builtin.module(func.func(test-alias-analysis-modref))' -split-input-file -allow-unregistered-dialect 2>&1 | FileCheck %s

// CHECK-LABEL: Testing : "no_side_effects"
// CHECK: alloc -> func.region0#0: NoModRef
// CHECK: dealloc -> func.region0#0: NoModRef
// CHECK: return -> func.region0#0: NoModRef
func.func @no_side_effects(%arg: memref<2xf32>) attributes {test.ptr = "func"} {
  %1 = memref.alloc() {test.ptr = "alloc"} : memref<8x64xf32>
  memref.dealloc %1 {test.ptr = "dealloc"} : memref<8x64xf32>
  return {test.ptr = "return"}
}

