
// CHECK-LABEL: Testing : "single_block_loop"
// CHECK-NEXT: Blocks : ^[[BB0:.*]], ^[[BB1:.*]], ^[[BB2:.*]]
// CHECK: Loop at depth 1 containing:
// CHECK-SAME: ^[[BB1]]<header><latch><exiting>
func.func @single_block_loop(%c: i1) {
  cf.br ^bb1
^bb1:
  cf.cond_br %c, ^bb1, ^bb2
^bb2:
  return
}

