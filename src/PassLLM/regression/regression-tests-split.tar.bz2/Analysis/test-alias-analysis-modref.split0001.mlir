
// CHECK-LABEL: Testing : "simple"
// CHECK-DAG: store -> alloc#0: Mod
// CHECK-DAG: load -> alloc#0: Ref

// CHECK-DAG: store -> func.region0#0: NoModRef
// CHECK-DAG: load -> func.region0#0: NoModRef
func.func @simple(%arg: memref<i32>, %value: i32) attributes {test.ptr = "func"} {
  %1 = memref.alloca() {test.ptr = "alloc"} : memref<i32>
  memref.store %value, %1[] {test.ptr = "store"} : memref<i32>
  %2 = memref.load %1[] {test.ptr = "load"} : memref<i32>
  return {test.ptr = "return"}
}

