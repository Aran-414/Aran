
// CHECK-LABEL: function: @test_fork
func.func @test_fork() -> () {
  // CHECK: init -> 1
  "test.branch"() [^bb0, ^bb1] {tag = "init", foo = 1 : ui64} : () -> ()

^bb0:
  // CHECK: a -> 3
  "test.branch"() [^bb2] {tag = "a", foo = 2 : ui64} : () -> ()

^bb1:
  // CHECK: b -> 5
  "test.branch"() [^bb2] {tag = "b", foo = 4 : ui64} : () -> ()

^bb2:
  // CHECK: end -> 6
  "test.foo"() {tag = "end"} : () -> ()
  return

}

