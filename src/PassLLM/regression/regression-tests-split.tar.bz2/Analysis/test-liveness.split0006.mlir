
// CHECK-LABEL: Testing : nested_region2

func.func @nested_region2(
  // CHECK: Block: 0
  // CHECK-NEXT: LiveIn:{{ *$}}
  // CHECK-NEXT: LiveOut:{{ *$}}
  // CHECK-NEXT: BeginLivenessIntervals
  // CHECK-NEXT: val_7
  // CHECK-NEXT:    %0 = arith.addi
  // CHECK-NEXT:    %1 = arith.addi
  // CHECK-NEXT:    scf.for
  // CHECK:         // %2 = arith.addi
  // CHECK-NEXT:    scf.for
  // CHECK:         // %3 = arith.addi
  // CHECK-NEXT: val_8
  // CHECK-NEXT:    %1 = arith.addi
  // CHECK-NEXT:    scf.for
  // CHECK:         // func.return %1
  // CHECK: EndLivenessIntervals
  // CHECK-NEXT: BeginCurrentlyLive
  // CHECK-NEXT: arith.addi
  // CHECK-SAME:   arg0@0 arg1@0 arg2@0 arg3@0 arg4@0 arg5@0 arg6@0 val_7
  // CHECK-NEXT: arith.addi
  // CHECK-SAME:   arg0@0 arg1@0 arg2@0 arg4@0 arg5@0 arg6@0 val_7 val_8
  // CHECK-NEXT: scf.for {{.*}}
  // CHECK-NEXT:   arith.addi
  // CHECK-NEXT:   scf.for {{.*}} {
  // CHECK-NEXT:     arith.addi
  // CHECK-NEXT:     memref.store
  // CHECK-NEXT:   }
  // CHECK-NEXT: arg0@0 arg1@0 arg2@0 arg5@0 arg6@0 val_7 val_8
  // CHECK-NEXT: return
  // CHECK-SAME:  val_8
  %arg0 : index, %arg1 : index, %arg2 : index,
  %arg3 : i32, %arg4 : i32, %arg5 : i32,
  %buffer : memref<i32>) -> i32 {
  %0 = arith.addi %arg3, %arg4 : i32
  %1 = arith.addi %arg4, %arg5 : i32
  scf.for %arg6 = %arg0 to %arg1 step %arg2 {
    // CHECK: Block: 1
    // CHECK-NEXT: LiveIn: arg0@0 arg1@0 arg2@0 arg5@0 arg6@0 val_7
    // CHECK-NEXT: LiveOut:{{ *$}}
    // CHECK-NEXT: BeginLivenessIntervals
    // CHECK-NEXT: val_10
    // CHECK-NEXT:    %2 = arith.addi
    // CHECK-NEXT:    scf.for
    // CHECK:         // %3 = arith.addi
    // CHECK: EndLivenessIntervals
    // CHECK-NEXT: BeginCurrentlyLive
    // CHECK-NEXT: arith.addi
    // CHECK-SAME:   arg0@0 arg1@0 arg2@0 arg5@0 arg6@0 val_7 arg0@1 val_10
    // CHECK-NEXT: scf.for {{.*}}
    // CHECK-NEXT:   arith.addi
    // CHECK-NEXT:   memref.store
    // CHECK-NEXT: arg0@0 arg1@0 arg2@0 arg6@0 val_7
    %2 = arith.addi %0, %arg5 : i32
    scf.for %arg7 = %arg0 to %arg1 step %arg2 {
      // CHECK: Block: 2
      // CHECK: BeginCurrentlyLive
      // CHECK-NEXT: arith.addi
      // CHECK-SAME:   arg6@0 val_7 val_10 arg0@2 val_12
      // CHECK-NEXT: memref.store
      // CHECK-SAME:   arg6@0 val_12
      // CHECK: EndCurrentlyLive
      %3 = arith.addi %2, %0 : i32
      memref.store %3, %buffer[] : memref<i32>
    }
  }
  return %1 : i32
}

