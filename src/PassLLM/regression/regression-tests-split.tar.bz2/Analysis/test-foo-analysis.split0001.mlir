
// CHECK-LABEL: function: @test_one_join
func.func @test_one_join() -> () {
  // CHECK: a -> 0
  "test.foo"() {tag = "a"} : () -> ()
  // CHECK: b -> 1
  "test.foo"() {tag = "b", foo = 1 : ui64} : () -> ()
  return
}

