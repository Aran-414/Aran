// RUN: mlir-opt %s -pass-pipeline="builtin.module(func.func(test-print-topological-sort))" --split-input-file | FileCheck %s

// CHECK-LABEL: single_element
func.func @single_element() {
  // CHECK: test_sort_index = 0
  return {test_to_sort}
}

