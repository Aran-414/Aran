
// CHECK-LABEL: Testing : nested_region3

func.func @nested_region3(
  // CHECK: Block: 0
  // CHECK-NEXT: LiveIn:{{ *$}}
  // CHECK-NEXT: LiveOut: arg0@0 arg1@0 arg2@0 arg6@0 val_7 val_8
  // CHECK-NEXT: BeginLivenessIntervals
  // CHECK-NEXT: val_7
  // CHECK-NEXT:    %0 = arith.addi
  // CHECK-NEXT:    %1 = arith.addi
  // CHECK-NEXT:    scf.for
  // CHECK:         // cf.br ^bb1
  // CHECK-NEXT:    %2 = arith.addi
  // CHECK-NEXT:    scf.for
  // CHECK:         // %2 = arith.addi
  // CHECK: EndLivenessIntervals
  // CHECK-NEXT: BeginCurrentlyLive
  // CHECK-NEXT: arith.addi
  // CHECK-SAME:   arg0@0 arg1@0 arg2@0 arg3@0 arg4@0 arg5@0 arg6@0 val_7
  // CHECK-NEXT: arith.addi
  // CHECK-SAME:   arg0@0 arg1@0 arg2@0 arg4@0 arg5@0 arg6@0 val_7 val_8
  // CHECK-NEXT: scf.for
  // COM: Skipping the body of the scf.for...
  // CHECK: arg0@0 arg1@0 arg2@0 arg5@0 arg6@0 val_7 val_8
  // CHECK-NEXT: cf.br
  // CHECK-SAME:   arg0@0 arg1@0 arg2@0 arg6@0 val_7 val_8
  // CHECK-NEXT: EndCurrentlyLive
  %arg0 : index, %arg1 : index, %arg2 : index,
  %arg3 : i32, %arg4 : i32, %arg5 : i32,
  %buffer : memref<i32>) -> i32 {
  %0 = arith.addi %arg3, %arg4 : i32
  %1 = arith.addi %arg4, %arg5 : i32
  scf.for %arg6 = %arg0 to %arg1 step %arg2 {
    // CHECK: Block: 1
    // CHECK-NEXT: LiveIn: arg5@0 arg6@0 val_7
    // CHECK-NEXT: LiveOut:{{ *$}}
    // CHECK: BeginCurrentlyLive
    // CHECK-NEXT: arith.addi
    // CHECK-SAME:   arg5@0 arg6@0 val_7 arg0@1 val_10
    // CHECK-NEXT: memref.store
    // CHECK-SAME:   arg6@0 val_10
    // CHECK-NEXT: EndCurrentlyLive
    %2 = arith.addi %0, %arg5 : i32
    memref.store %2, %buffer[] : memref<i32>
  }
  cf.br ^exit

^exit:
  // CHECK: Block: 2
  // CHECK-NEXT: LiveIn: arg0@0 arg1@0 arg2@0 arg6@0 val_7 val_8
  // CHECK-NEXT: LiveOut:{{ *$}}
  // CHECK: BeginCurrentlyLive
  // CHECK: scf.for
  // CHECK: arg0@0 arg1@0 arg2@0 arg6@0 val_7 val_8
  // CHECK-NEXT: return
  // CHECK-SAME:   val_8
  // CHECK-NEXT: EndCurrentlyLive
  scf.for %arg7 = %arg0 to %arg1 step %arg2 {
    // CHECK: Block: 3
    // CHECK-NEXT: LiveIn: arg6@0 val_7 val_8
    // CHECK-NEXT: LiveOut:{{ *$}}
    // CHECK: BeginCurrentlyLive
    // CHECK-NEXT: arith.addi
    // CHECK-SAME:   arg6@0 val_7 val_8 arg0@3 val_12
    // CHECK-NEXT: memref.store
    // CHECK-SAME:   arg6@0 val_12
    // CHECK-NEXT: EndCurrentlyLive
    %2 = arith.addi %0, %1 : i32
    memref.store %2, %buffer[] : memref<i32>
  }
  return %1 : i32
}

