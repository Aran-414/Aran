// RUN: mlir-opt -split-input-file -pass-pipeline='builtin.module(func.func(test-foo-analysis))' %s 2>&1 | FileCheck %s

// CHECK-LABEL: function: @test_default_init
func.func @test_default_init() -> () {
  // CHECK: a -> 0
  "test.foo"() {tag = "a"} : () -> ()
  return
}

