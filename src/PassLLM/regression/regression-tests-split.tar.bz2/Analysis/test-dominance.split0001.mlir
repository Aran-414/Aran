
// CHECK-LABEL: Testing : func_loop
func.func @func_loop(%arg0 : i32, %arg1 : i32) {
  cf.br ^loopHeader(%arg0 : i32)
^loopHeader(%counter : i32):
  %lessThan = arith.cmpi slt, %counter, %arg1 : i32
  cf.cond_br %lessThan, ^loopBody, ^exit
^loopBody:
  %const0 = arith.constant 1 : i32
  %inc = arith.addi %counter, %const0 : i32
  cf.br ^loopHeader(%inc : i32)
^exit:
  return
}

// CHECK: --- DominanceInfo ---
// CHECK: Nearest(0, 0) = 0
// CHECK: Nearest(0, 1) = 0
// CHECK: Nearest(0, 2) = 0
// CHECK: Nearest(0, 3) = 0
// CHECK: Nearest(0, 4) = 4
// CHECK: Nearest(1, 0) = 0
// CHECK: Nearest(1, 1) = 1
// CHECK: Nearest(1, 2) = 1
// CHECK: Nearest(1, 3) = 1
// CHECK: Nearest(1, 4) = 4
// CHECK: Nearest(2, 0) = 0
// CHECK: Nearest(2, 1) = 1
// CHECK: Nearest(2, 2) = 2
// CHECK: Nearest(2, 3) = 1
// CHECK: Nearest(2, 4) = 4
// CHECK: Nearest(3, 0) = 0
// CHECK: Nearest(3, 1) = 1
// CHECK: Nearest(3, 2) = 1
// CHECK: Nearest(3, 3) = 3
// CHECK: Nearest(3, 4) = 4
// CHECK: Nearest(4, 0) = 4
// CHECK: Nearest(4, 1) = 4
// CHECK: Nearest(4, 2) = 4
// CHECK: Nearest(4, 3) = 4
// CHECK: Nearest(4, 4) = 4

// CHECK: --- PostDominanceInfo ---
// CHECK: Nearest(0, 0) = 0
// CHECK: Nearest(0, 1) = 1
// CHECK: Nearest(0, 2) = 1
// CHECK: Nearest(0, 3) = 3
// CHECK: Nearest(0, 4) = 4
// CHECK: Nearest(1, 0) = 1
// CHECK: Nearest(1, 1) = 1
// CHECK: Nearest(1, 2) = 1
// CHECK: Nearest(1, 3) = 3
// CHECK: Nearest(1, 4) = 4
// CHECK: Nearest(2, 0) = 1
// CHECK: Nearest(2, 1) = 1
// CHECK: Nearest(2, 2) = 2
// CHECK: Nearest(2, 3) = 3
// CHECK: Nearest(2, 4) = 4
// CHECK: Nearest(3, 0) = 3
// CHECK: Nearest(3, 1) = 3
// CHECK: Nearest(3, 2) = 3
// CHECK: Nearest(3, 3) = 3
// CHECK: Nearest(3, 4) = 4
// CHECK: Nearest(4, 0) = 4
// CHECK: Nearest(4, 1) = 4
// CHECK: Nearest(4, 2) = 4
// CHECK: Nearest(4, 3) = 4
// CHECK: Nearest(4, 4) = 4

// CHECK: --- Block Dominance relationship ---
// CHECK: dominates(0, 0) = 1 (properly = 0)
// CHECK: dominates(0, 1) = 1 (properly = 1)
// CHECK: dominates(0, 2) = 1 (properly = 1)
// CHECK: dominates(0, 3) = 1 (properly = 1)
// CHECK: dominates(0, 4) = 0 (properly = 0)
// CHECK: dominates(1, 0) = 0 (properly = 0)
// CHECK: dominates(1, 1) = 1 (properly = 0)
// CHECK: dominates(1, 2) = 1 (properly = 1)
// CHECK: dominates(1, 3) = 1 (properly = 1)
// CHECK: dominates(1, 4) = 0 (properly = 0)
// CHECK: dominates(2, 0) = 0 (properly = 0)
// CHECK: dominates(2, 1) = 0 (properly = 0)
// CHECK: dominates(2, 2) = 1 (properly = 0)
// CHECK: dominates(2, 3) = 0 (properly = 0)
// CHECK: dominates(2, 4) = 0 (properly = 0)
// CHECK: dominates(3, 0) = 0 (properly = 0)
// CHECK: dominates(3, 1) = 0 (properly = 0)
// CHECK: dominates(3, 2) = 0 (properly = 0)
// CHECK: dominates(3, 3) = 1 (properly = 0)
// CHECK: dominates(3, 4) = 0 (properly = 0)
// CHECK: dominates(4, 0) = 1 (properly = 1)
// CHECK: dominates(4, 1) = 1 (properly = 1)
// CHECK: dominates(4, 2) = 1 (properly = 1)
// CHECK: dominates(4, 3) = 1 (properly = 1)
// CHECK: dominates(4, 4) = 1 (properly = 1)

// CHECK: --- Block PostDominance relationship ---
// CHECK: postdominates(0, 0) = 1 (properly = 0)
// CHECK: postdominates(0, 1) = 0 (properly = 0)
// CHECK: postdominates(0, 2) = 0 (properly = 0)
// CHECK: postdominates(0, 3) = 0 (properly = 0)
// CHECK: postdominates(0, 4) = 0 (properly = 0)
// CHECK: postdominates(1, 0) = 1 (properly = 1)
// CHECK: postdominates(1, 1) = 1 (properly = 0)
// CHECK: postdominates(1, 2) = 1 (properly = 1)
// CHECK: postdominates(1, 3) = 0 (properly = 0)
// CHECK: postdominates(1, 4) = 0 (properly = 0)
// CHECK: postdominates(2, 0) = 0 (properly = 0)
// CHECK: postdominates(2, 1) = 0 (properly = 0)
// CHECK: postdominates(2, 2) = 1 (properly = 0)
// CHECK: postdominates(2, 3) = 0 (properly = 0)
// CHECK: postdominates(2, 4) = 0 (properly = 0)
// CHECK: postdominates(3, 0) = 1 (properly = 1)
// CHECK: postdominates(3, 1) = 1 (properly = 1)
// CHECK: postdominates(3, 2) = 1 (properly = 1)
// CHECK: postdominates(3, 3) = 1 (properly = 0)
// CHECK: postdominates(3, 4) = 0 (properly = 0)
// CHECK: postdominates(4, 0) = 1 (properly = 1)
// CHECK: postdominates(4, 1) = 1 (properly = 1)
// CHECK: postdominates(4, 2) = 1 (properly = 1)
// CHECK: postdominates(4, 3) = 1 (properly = 1)
// CHECK: postdominates(4, 4) = 1 (properly = 1)

// CHECK: module attributes {test.block_ids = array<i64: 4>}
// CHECK:   func.func @func_loop({{.*}}) attributes {test.block_ids = array<i64: 0, 1, 2, 3>}

