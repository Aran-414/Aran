
// CHECK-LABEL: Testing : "nested"
module attributes {test.name = "nested"} {
  module @nested_module {
    // CHECK: Node{{.*}}func_a
    func.func @func_a() {
      return
    }
  }

  // CHECK: Node{{.*}}func_b
  // CHECK: Call-Edge{{.*}}func_a
  func.func @func_b() {
    "test.conversion_call_op"() { callee = @nested_module::@func_a } : () -> ()
    return
  }
}

