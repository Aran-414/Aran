
func.func @base_test(%arg0: i32, %arg1: f32) {
  return
}

// TEST_2: Overriding parsing of TestI32Type encoding...
// TEST_2: func.func @base_test([[ARG0:%.+]]: !test.i32, [[ARG1:%.+]]: f32) {
