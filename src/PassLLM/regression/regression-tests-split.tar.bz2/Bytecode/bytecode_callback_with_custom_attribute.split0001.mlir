
"test.versionedC"() <{attribute = dense<[42, 24]> : tensor<2xi32>}> : () -> ()

// TEST_4: Overriding parsing of TestAttrParamsAttr encoding...
// TEST_4: "test.versionedC"() <{attribute = #test.attr_params<42, 24>}> : () -> ()
